### 34 OBV交易策略
### 34.2 OBV指标计算方法
## 累积OBV
import imp
from re import T
from telnetlib import TSPEED
from turtle import title
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
TsingTao=pd.read_cav('TsingTao.csv',index_col='Date')
TsingTao.index=pd.to_datetime(TsingTao.index)
TsingTao.Volume=TsingTao.Volume.replace(0,np.nan)
TsingTao=TsingTao.dropna()
close=TsingTao.Close
Volume=TsingTao.Volume

difClose=close.diff()
difClose[0]=0
OBV=(((difClose>=0)*2-1)*Volume).cumsum()
OBV.name='OBV'
OBV.head()
OBV.describe()
## 移动OBV
import movingAverage as mv
smOBV=mv.smaCal(OBV,9)
smOBV.tail()
## 修正型OBV
AdjOBV=((close-TsingTao.Low)-(TsingTao.High-close))/(TsingTao.High-TsingTao.Low)*Volume
AdjOBV.name='AdjOBV'
AdjOBV.head()
AdjOBVd=AdjOBV.cumsum()
AdjOBVd.name='AdjOBVd'
AdjOBVd.describe()

ax1=plt.subplot(311)
close.plot(title='青岛啤酒收盘价')
plt.xticks(close.index[1:3],(''))
plt.xlabel('')
ax2=plt.subplot(312)
OBV.plot(label='OBV',title='青岛皮杰累积能量潮与移动能量潮')
smOBV.plot(label='smOBV',linestyle='-.',color='r')
plt.legend(loc='upper left')
plt.xticks(close.index[1:3],(''))
plt.xlabel('')
ax3=plt.subplot(313)
AdjOBV.plot(title='成交量多空比率净额')
for ax in ax1,ax2,ax3:
    ax.grid(True)


### 34.3 OBV指标的理论依据
### 34.4 OBV指标的交易策略制定
