# 9.3 Python内置数据类型与操作
## 9.3.1 序列类型数据操作
### 9.3.1.1 list类型与操作
# list类型的对象可以通过list()函数来创建
L1 = list([123,23,[4,5,6],'abc'])
print(L1)
# [123, 23, [4, 5, 6], 'abc']

# 序列类型的共同操作
# s[i:j:k] 返回s索引序列的切片，以k为步长，起始值为i，结束值为j
# s.index(x[,i[,j]]) 返回x在序列s或者切片s[i:j]中第一次出现的索引值
# s.count(x) 返回序列s中，元素x出现的次数

# append()函数一次只能增加一个元素
# 若要在列表中增加多个元素，可以调用extend()函数
L2 = ['python']
L2.extend([123,'price',7,8,9])
print(L2)
# ['python', 123, 'price', 7, 8, 9]
# 若使用append函数则会把传入的列表对象当做一个元素增加到L2中

# 列表元素的增加还可以通过"+"和"+="来实现
# "+"将值传给了一个新的列表
# "+="则将连接在一起后的值重新赋值给原来的变量

# insert()函数插入列表元素
# insert(i, x)
# i为指定位置，x为指定内容

# pop()和remove(x)删除列表元素
# pop()用于删除一个列表最右端的元素，并打印出删除的元素值
# 而remove(x)函数用于删除指定的元素x，若x在列表中，则删除第一次出现的x，若x不在列表中则会报错
# 在用remove(x)删除x之前可以先使用count(x)来对x计数
# pop()函数也可以传入一个参数i，pop(i)返回列表索引值为i的元素值，并删除

# 列表类型的常用方法
# List1.sort() 对列表中的元素升序排列
# List1.reverse() 对列表中的元素降序排列


### 9.3.1.2 tuple类型与操作
# 内建函数tuple()用于创建一个元组对象
# 元租对象也可以用逗号或者小括号来创建
tu2 = 123,6,7,8,'python'
print(type(tu2))
# <class 'tuple'>
# 创建只有1个元素的元组时，元素后面需加逗号，以免歧义

# 如果想要把列表类型的数据更改成元组数据，也可以通过tuple()函数实现

# 元组属于不可变对象，不能增加、删除元组中的元素
# 但是元组对象可以进行连接而创建一个新的元组对象
tu4 = 2,9,10
tu5 = 4.0,True,False
tu6 = tu4 + tu5
print(tu6)
# (2, 9, 10, 4.0, True, False)
print(tu4)
# (2, 9, 10)
# 元组tu4没有改变

# 元组也可以使用乘法
tu7 = tu4*3
print(tu7)
# (2, 9, 10, 2, 9, 10, 2, 9, 10)

### 9.3.1.3 range类型与操作
# 只传入一个参数时，表示生成一个初始值为0，间隔值为1，终止值为stop-1的等差序列
# range(stop)
# 第一个参数为初始值，第二个参数为终止参照值，第三个参数表示步长
# range(start, stop, step)

# range对象属于可迭代对象，其可作为list()或tuple()函数的传入参数
r1 = range(5)
list1 = list(r1)
print(list1)
# [0, 1, 2, 3, 4]

# range类型的对象不能使用乘法*

### 9.3.1.4 字符串的操作
# 若创建的字符串中包含单引号或者双引号，为避免歧义，需要将整个字符串数据放入三引号内
# 字符串生成函数str()用于创建一个字符串对象，该函数也会把其他类型的数据转变成字符串对象
# 字符串类型数据也属于不可变的序列数据

# 字符串分割与连接
# split()方法把一个长字符串从空格出或者标点符号出隔开。
GeogeSoros = """I'm only rich because I know when I'm wrong, /
I basically have survived by recognizing my mistakes."""
print(GeogeSoros.split()) # 默认以空格分隔
# ["I'm", 'only', 'rich', 'because', 'I', 'know', 'when', "I'm", 'wrong,', '/', 'I', 'basically', 'have', 'survived', 'by', 'recognizing', 'my', 'mistakes.']
# 以逗号为分割点，最大分割数为1（即分割1次）
text1 = '234,456,345'.split(',',maxsplit=1)
print(text1)
# ['234', '456,345']
# 以字符'3'为分割点
text2 = '234,456,345'.split('3')
print(text2)
# ['2', '4,456,', '45']

# 英文字母大小写转换操作
# str.islower() 如果字符串对象中所有字符均为小写字母，返回True
# str.isupper() 如果字符串对象中所有字符均为大写字母，返回False
# str.lower() 将字符串对象中的所有字符转变成小写字母
# str.upper() 将字符串对象中的所有字符转变成大写字母
# str.istitle() 如果字符串对象中无空格的连续字符的首字母均大写，其余部分均小写，返回True
# str.title() 将字符串对象无空格的连续字符转变成首字母大写，其余部分均小写的形式
# str.capitalize() 将字符串对象的首字母大写，其余部分均小写
# str.swapcase() 将字符串中的字母大小写调换

# 在文本分析时，大写的单词和小写的单词应该看作同一个词
# 因此在词频统计的第一步最好先把字符串的字符全部改成小写，再进行词频统计
count1 = 'stock stocK Stock Stock stock'.lower().count('stock')
print(count1)
# 5

# 字符串的查找、删除与替换操作
# 返回字符串x出现在字符串对象str中的最左边位置
# str.find(x) 如果x不在str对象中，返回值为-1
# str.index(x) 如果x不在str对象中，会报错
# 返回字符串x出现在字符串对象str中的最右边位置
# str.rfind(x) 
# str.rindex(x) 
# str.startswith(x) 参数x为元组或者字符串，如果对象str以x或者x元组中的某一个元素开头，则返回True
# str.endswith() 参数x为元组或者字符串，如果对象str以x或者x元组中的某一个元素结束，则返回True
# str.strip([chars]) 删去对象str开始和结束处与参数字符chars相同的部分
# str.rstrip([chars]) 删去对象str结束处与参数字符chars相同的部分

## 9.3.2 字典类型操作
# dict()函数与花括号均可以创建字典
SSEC1 = {'Date':'02-Mar-2015','Open':3332.7,'High':3336.8,'Low':3298.7,'Close':3336.3}
# 调用keys()方法查看字典对象的键
print(SSEC1.keys())
# dict_keys(['Data', 'Open', 'High', 'Low', 'Close'])
# 调用values()方法查看字典对象的值
print(SSEC1.values())
# dict_values(['02-Mar-2015', 3332.7, 3336.8, 3298.7, 3336.3])

# 字典中的键或者值具有迭代的性质，可以用于循环语句中

# 值的获取与更改
# 通过键来索引
print(SSEC1['Open'])
# 3332.7
# 调用get()方法
print(SSEC1.get('Open'))
# 3332.7

# 若要更新字典对象中键的取值，也可以调用update()方法
SSEC1.update(Open=2332.7,High=2336.8,Low=2298.7,Close=2336.3)

# 字典元素的增加、删除与复制
# del语句可以删除特定的键及其相对应的值
del SSEC1['Date']
print('Date' in SSEC1) # False
# 如果调用clear()方法，则删除字典中额所有内容，返回空字典
SSEC2 = SSEC1.copy()
print(SSEC2.clear()) # None

## 9.3.3 集合操作
# set和frozenset
# set类型对象是可变的，可以增减其中的元素，frozenset类型对象是不可变的
# 可以通过set()函数创建set()类型的对象，通过frozenset()函数创建frozenset()类型的对象
list1 = [2,3,4,5,3,2,67]
set2 = set(list1) # 删除重复元素
print(set2) # {2, 67, 3, 4, 5}
# set对象也可以用花括号来创建
set3 = {'Open','Close','High','High'}
print(type(set3)) # <class 'set'>

# set类型对象可以调用add()方法增加元素，调用remove()函数删除集合中的特点元素
# 而frozenset类型的对象则没有这两种方法
# len()函数均适用于set对象和frozenset对象，因为集合中的元素可迭代，所以集合对象能够被for循环遍历

# 通过for循环，可以把集合对象中的元素用作字典对象的键，而列表中的元素当做字典对象的值
list2 = [23.1,24,24.3,22.9]
d = dict()
j = 0
for i in set3:
    d[i] = list2[j]
    j += 1
print(d) # {'Open': 23.1, 'High': 24, 'Close': 24.3}

# 集合之间的运算
# set1.union(set2)                set1 | set2  并运算
# set1.intersection(set2)         set1 & set2  交运算
# set1.difference(set2)           set1 - set2  差运算，删去set1和set2中相同的元素
# set1.symmetric_difference(set2) set1 ^ set2  对称差运算，返回set1与set2共有元素以外的元素
# set1.issubset(set2)             set1 <= set2 如果set1是set2的子集，返回True
# set1.issuperset(set2)           set1 >= set2 如果set2是set1的子集，返回False
# set1.isdisjoint(set2)                        如果set1和set2无交集，返回True
