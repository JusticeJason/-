### 18 资产收益率和风险
# 收益率=投资收益/投资成本，投资成本=资产单价*资产数量
# 资本利得（可正可负）：由资产价格变化所产生的收益
# 期间投资收益=期末价格-期初价格+其他收益
# 期间收益率=（期末价格-期初价格+其他期间收益）/期初价格
# 期间净收益率=（期末价格-期初价格+其他期间收益-卖出交易成本）/（期初价格+买入交易成本）
# 预期收益率：投资人欲购买某资产之前，预估未来可以获得的收益率水平；
# 实际收益率：投资人投入某资产后，实际获得的报酬率


### 18.1 单期与多期简单收益率
# 资产持有期间不同，会带给投资者不同的效益

### 18.1.1 单期简单收益率
# 单期简单收益率Rt=(Pt-Pt-1)/Pt-1，简单毛收益率为1+Rt

### 18.1.2 多期简单收益率
# Rt(k)=(Pt-Pt-k)/Pt-k
from ffn.core import annualize
import pandas as pd
from pandas.tseries.offsets import SemiMonthBegin
close=pd.read_csv('C:\\Users\\86189\\Desktop\\表18.1.csv',index_col='date')
# 转化成带日期的格式，即时间序列
close.index=pd.to_datetime(close.index)
close.index.name='Date'
close=close.rename(columns={"price":"close"})
# print(close)
# 将收盘价滞后一期
lagclose=close.shift(1)
lagclose=lagclose.rename(columns={"close":"lagclose"})
# 合并close,lagclose这两个收盘价数据
Calclose=pd.concat([close,lagclose],axis=1)
# 计算单期简单收益
simpleret=(Calclose["close"]-Calclose["lagclose"])/Calclose["lagclose"]
simpleret.name='simpleret'
# print(simpleret)
calret=pd.merge(Calclose,pd.DataFrame(simpleret),left_index=True,right_index=True)
# print(calret)
# 计算2期简单收益率
simpleret2=(close-close.shift(2))/close.shift(2)
simpleret2.name='simpleret2'
calret['simpleret2']=simpleret2
# print(calret)
# 查看1月9日的数据
# print(calret.iloc[5,:])

### 18.1.3 Python函数计算简单收益率
import ffn
ffnSimpleret=ffn.to_returns(close)
ffnSimpleret.name='ffnSimpleret'
# print(ffnSimpleret)

### 18.1.4 单期与多期简单收益率的关系
# Rt(2)=(1+Rt)(1+Rt-1)-1，其中(1+Rt)(1+Rt-1)即复利
# 复利指每一期将赚到的钱作为本金投入到下一期的资产中，以此类推，直至投资期结束获得的总收益
# Rt(k)=(1+Rt-k+1)(1+Rt-k+2)...(1+Rt)-1
# 多期收益率的计算还有一种算法，就是将单期收益率简单加总，这样的算法没有考虑到复利的效果
# 与单期收益率相加或者相乘计算多期效益率对应，由多期计算单期也有两种方式
# 一种是算术平均，一种是几何平均（考虑复利）

### 18.1.5 年化收益率
# 年化收益率只是一种理论上的收益率，并不是投资人真正能够获得的收益率
# 年收益率是指投资一笔资产一年的实际收益率
# 假设投资人持有资产时间为T期，获得收益率为RT，一年共有m个单期
# 年化收益率为RT/T*m，或[(1+RT)^(1/T)-1]*m
# 其中RT/T是算术平均收益率，(1+RT)^(1/T)-1是几何平均收益率
# 其他公式：(1+RT)^(1/(T/m))-1, (r1+...+ri+...+rN)/T*m(简单加总), [(1+r1)(1+r2)...(1+rN)]^(1/(T/m))-1
# python计算；假设一年有245个交易日
annualize = (1+simpleret).cumprod()[-1]**(245/311)-1 # cumprod()累乘函数
# print(annualize) 
# 自定义函数
def annualize(returns, period):
    if period == 'day':
        return((1+returns).cumprod()[-1]**(245/len(returns))-1)
    elif period == 'month':
        return((1+returns).cumprod()[-1]**(12/len(returns))-1)
    elif period == 'quarter':
        return((1+returns).cumprod()[-1]**(4/len(returns))-1)
    elif period == 'year':
        return((1+returns).cumprod()[-1]**(1/len(returns))-1)
    else:
        raise Exception("Wrong period")

### 18.1.6 考虑股利分红的简单收益率
# 公司发放股利的方式：现金股利和股票股利（纳税）
# 转增股本（不用纳税）：是公司将资本公积金转化为股本，不受公司本年度可分配利润多少及时间限制
# 公司发放股利涉及的重要日期：股利宣告日、股权登记日、除权除息日、股利发放日
# 除息价=股息登记日的收盘价-每股红利现金额
# 送红股后的除权价=股权登记日的收盘价/(1+每股送红股数或转增股数)
# 除权除息价=(股权登记日的收盘价-每股红利现金额)/(1+每股送红股数或转增股数)
# 股息率=Div/Price*100%，是判断股利高低的重要参考，也是衡量公司是否具有投资价值的重要指标
# 市盈率（本益比）=每股市价/每股盈利，衡量的是，如果公司未来能够维持过去一年的盈利水平，投资人以市场价格购入该公司股票，多长时间可以赚回本金
# 理论上，股票的市盈率越低代表该股票的风险越低，但市盈率变动大


### 18.2 连续复利收益率
# 连续复利的概念是投资期数趋于无穷大、而不同期之间的时间间隔无穷小，分分秒秒都在复利
# 如果单期简单收益率（未考虑复利）是R，该段期间有n个复利结算周期，对应的T期收益率为：
# (1+R/n)^(nT)-1，n趋于正无穷时，可得T期连续复利的收益率为e^(RT)-1
# 假设单期收益率是Rt，通过连续复利产生与Rt相同收益的单期复利收益率叫作连续复利收益率
# 该收益率（rt）满足：1+Rt=e^(rt)
# 如果1+Rt是用资产的期初价格Pt-1及期末价格Pt求得，则：rt=lnPt-lnPt-1
import numpy as np
comporet=np.log(Calclose["close"]/Calclose["lagclose"])
comporet.name='comporet'
# print(comporet)
# print(comporet[5])
import ffn
ffnComporet=ffn.to_log_returns(close)
# print(ffnComporet)

### 18.2.1 多期连续复利收益率
# 2期连续复利收益率e^(rt(2))=1+Rt(2)
# k期连续复利收益率rt(k)=lnPt-lnPt-k
comporet2=np.log(close/close.shift(2))
comporet2.name='comporet2'
# print(comporet2)

### 18.2.2 单期与多期连续复利收益率的关系
# rt(2)=rt+rt-1，即2期连续复利收益率等于前一天和当天的单期复利收益率之和
# 连续复利收益率的优良性质：单期加总即得多期
comporet=comporet.dropna()
# print(comporet)
sumcomporet=comporet+comporet.shift(1)
# print(sumcomporet)


### 18.3 绘制收益图
# 收益图有两种：一种是将计算得到的收益率序列绘制出来，一种是绘制出累计收益率曲线
# 绘制收益率序列
import matplotlib; matplotlib.use('TkAgg')
from matplotlib import pyplot as plt
x=simpleret.index
y1=simpleret
plt.plot(x,y1)
plt.show()
# 绘制累计收益率曲线
y2=((1+simpleret).cumprod()-1)
plt.plot(x,y2)
plt.show()
