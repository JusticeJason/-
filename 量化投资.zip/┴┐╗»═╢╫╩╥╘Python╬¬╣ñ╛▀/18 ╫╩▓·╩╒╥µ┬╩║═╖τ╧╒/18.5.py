### 18.5 资产风险的测度

### 18.5.1 方差
from re import M
import pandas as pd
import ffn
from pandas.core.arrays.integer import safe_cast
# 计算风险大小
SApower=pd.read_csv('600343.csv',index_col='Date')
SApower.index=pd.to_datetime(SApower.index)
returnS=ffn.to_returns(SApower.Close)
# 标准差越大风险越大
print(returnS.std()) # 0.03480329900842775

### 18.5.2 下行风险
def cal_half_dev(returns):
    mu=returns.mean()
    temp=returns[returns<mu]
    half_devidtion=(sum((mu-temp)**2)/len(returns))**0.5
    return(half_devidtion) 
# 结果越大下行风险越大
print(cal_half_dev(returnS)) # 0.025624457436492557

### 18.5.3 风险价值
# 历史模拟法
print(returnS.quantile(0.05)) # 求四分位数：-0.08847577821543841
# 有5%的可能下跌超过8.8%，风险较大
# 协方差矩阵法：VaR=-(Zασ+μ)W，其中Zα是标准正态分布下α%对应的分位数
from scipy.stats import norm
# 计算给定正态分布值的概率
print(norm.ppf(0.05,returnS.mean(),returnS.std())) # -0.06557215434206443
# 蒙特卡洛方法

### 18.5.4 期望亏空ES
print(returnS[returnS<=returnS.quantile(0.05)].mean()) # -0.09091244523852665
# ES得到的损失水平大于VaR，但是在进行比较时，两者的结论仍是一致的

### 18.5.5 最大回撤MDD
# 最大回撤常用来描述投资者在持有资产时可能面临的最大亏损
import datetime
r=pd.Series([0, 0.1, -0.1, -0.01, 0.01, 0.02],index=[datetime.date(2015,7,x) for x in range(3,9)])
# print(r)
value=(1+r).cumprod() # 资产价值
# print(value)
D=value.cummax()-value # cummax求累计最大值；D为回撤值
# print(D)
d=D/(D+value) # 回撤率
# print(d)
MDD=D.max() # 最大回撤
print(MDD) # 0.1199
mdd=d.max() # 最大回撤率
print(mdd) # 0.109
# 调用ffn.calc_max_drawdown()来验证计算过程
print(ffn.calc_max_drawdown(value)) # -0.10899999999999999
print(ffn.calc_max_drawdown((1+returnS).cumprod())) # 最大回撤越大风险越大
