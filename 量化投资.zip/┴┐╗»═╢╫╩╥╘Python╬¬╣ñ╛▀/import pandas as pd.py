import pandas as pd
sh=pd.read_csv('019stock.csv',index_col="date")
sh.index=pd.to_datetime(sh.index)
# 定义配对形成期
formStart='2021-01-07'
formEnd='2022-01-07'
# 形成期数据
shform=sh[formStart:formEnd]
# 查看这50只股票形成期的前2期价格数据
print(shform.head(n=2))
PAf=shform['byjc']
PBf=shform['hxyh']
# 将两只股票数据合在一起形成DataFrame
pairf=pd.concat([PAf,PBf],axis=1)
# 求形成期长度
import numpy as np
print(len(pairf))
def SSD(priceX,priceY):
    if priceX is None or priceY is None:
        print('缺少价格序列')
    returnX=(priceX-priceX.shift(1))/priceX.shift(1)[1:]
    returnY=(priceY-priceY.shift(1))/priceY.shift(1)[1:]
    standardX=(returnX+1).cumprod()
    standardY=(returnY+1).cumprod()
    SSD=np.sum((standardX-standardY)**2)
    return(SSD)
# 求中国太保与保利地产价格的距离
dis=SSD(PAf,PBf)
print(dis)
# 协整模型
from arch.unitroot import ADF
# 检验中国银行对数价格的一阶单整性
# 将中国银行股股价取对数
PAflog=np.log(PAf)
# 对中国太保对数价格进行单位根检验
adfA=ADF(PAflog)
print(adfA.summary().as_text())
# 大于，不能拒绝原假设，非平稳
# 将中国银行对数价格差分
retA=PAflog.diff()[1:]
adfretA=ADF(retA)
print(adfretA.summary().as_text())
# 小于，能拒绝原假设，不存在单位根，平稳