### 30 均线系统策略
### 30.1 简单移动平均
### 30.1.1 简单移动平均数
# 获取青岛啤酒交易数据
from cProfile import label
from re import A
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
TsingTao=pd.read_csv('TsingTao.csv')
TsingTao.index=TsingTao.iloc[:,1]
TsingTao.index=pd.to_datetime(TsingTao.index,format="%Y-%m-%d")
TsingTao=TsingTao.iloc[:,2:]
TsingTao.head(3)
# 提取收盘价数据
Close=TsingTao.Close
# 绘制收盘价数据时序图
plt.rcParams['font.sans-serif']=['SimHei']
plt.subplot(111)
plt.plot(Close,'k')
plt.xlabel('date')
plt.ylabel('Close')
plt.title('2014年青岛啤酒股票收盘价时序图')
Sma5=pd.Series(0.0,index=Close.index)
for i in range(4,len(Close)):
    Sma5[i]=sum(Close[(i-4):(i+1)])/5
Sma5.tail()
plt.plot(Close[4:],label="Close",color="g")
plt.plot(Sma5[4:],label="Sma5",color='r',linestyle='dashed')
plt.title("青岛啤酒收盘价与简单移动平均线")
plt.tlim(35,50)
plt.legend()

### 30.1.2 简单移动平均函数
def smaCal(tsPrice,k):
    import pandas as pd
    Sma=pd.Series(0.0,index=tsPrice.index)
    for i in range(k-1,len(Close)):
        Sma[i]=sum(Close[(i-k+1):(i+1)])/k
    return(Sma)
sma5=smaCal(Close,5)
sma5.tail()

### 30.1.3 期数选择


### 30.2 加权移动平均
### 30.2.1 加权移动平均数
# 定义权重
b=np.array([1,2,3,4,5])
w=b/sum(b)
print(w)
# 根据青岛啤酒前5日收盘价来演示第5个交易日的加权平均数的求法
m1Close=Close[0:5]
wec=w*m1Close
sum(wec)
Wma5=pd.Series(0.0,index=Close.index)
for i in range(4,len(Close)):
    Wma5[i]=sum(w*Close[(i-4):(i+1)])
print(Wma5[2:7])
plt.rcParams['font.sans-serif']=['SimHel']
plt.plot(Close[4:],label="Close",color='g')
plt.plot(Wma5[4:],label="Swma5",color="r",linestyle="dashed")
plt.title("青岛啤酒收益加权移动平均线")
plt.ylim(35,50)
plt.legend()

### 30.2.2 加权移动平均函数
def wmaCal(tsPrice,weight):
    import pandas as pd
    import numpy as np
    k=len(weight)
    arrWeight=np.array(weight)
    Wma=pd.Series(0.0,index=tsPrice.index)
    for i in range(l-1,len(tsPrice.index)):
        Wma[i]=sum(arrWeight*tsPrice[(i-k+1):(i+1)])
    return(Wma)
# 计算青岛啤酒价格的加权移动平均值
wma5=wmaCal(Close,w)
wma5.head()
wma5_weight=wmaCal(Close,[0.1,0.15,0.2,0.25,0.3])
wma5_weight.tail()


### 30.3 指数加权移动平均
### 30.3.1 指数加权移动平均数
Ema5_number1=np.mean(Close[0:5])
Ema5_number2=0.2*Close[5]+(1-0.2)*Ema5_number1
Ema5[4]=Ema5_number1
Ema5[5]=Ema5_number2
# 计算第7天及以后的指数移动平均数
for i in range(6,len(Close)):
    expo=np.array(sorted(range(i-4),reverse=True))
    w=(1-0.2)**expo
    Ema5[i]=sum(0.2*w*Close[5:(i+1)])+Ema5_number1*0.2**(i-5)
Ema5.tail()
plt.rcParams['font.sans-serif']=['SimHel']
plt.plot(Close[4:],label="Close",color='g')
plt.plot(Wma5[4:],label="Swma5",color="r",linestyle="dashed")
plt.title("青岛啤酒收益加权移动平均线")
plt.ylim(35,50)
plt.legend()

### 30.3.2 指数加权移动平均函数
def ewmaCal(tsprice,period=5,exponential=0.2):
    import pandas as pd
    import numpy as np
    Ewma=pd.Series(0.0,index=tsprice.index)
    Ewma[period-1]=np.mean(tsprice[:period])
    for i in range(period,len(tsprice)):
        Ewma[i]=exponential*tsprice[i]+(1-exponential)*Ewma[period-1]
    return(Ewma)
Ewma=ewmaCal(Close,5,0.2)
Ewma.head()


### 30.4 创建movingAverage模组
import movingAverage as ma
Ewma10=ma.ewmaCal(Close,10,0.2)
Ewma10.tail(3)

### 30.5 常用平均方法的比较
### 30.6 中国银行股价数据与均线分析
## 提取出收盘价数据，并对收盘价进行总结分析
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import movingAverage as ma
ChinaBank=pd.read_csv('ChinaBank.csv')
ChinaBank.index=ChinaBank.iloc[:,1]
ChinaBank.index=pd.to_datetime(ChinaBank.index,format='%Y-%m-%d')
ChinaBank=ChinaBank.iloc[:,2:]
CBClose=ChinaBank.Close
CBClose.describe()
## 提取出中国银行2015年的收盘价数据，以10天为跨度，计算三种平均价
Close15=CBC['2015']
Sma10=ma.smaCal(Close15,10)
Sma10.tail()
weight=np.array(range(1,11))/sum(range(1,11))
Wma10=ma.wmaCal(Close15,weight)
Wma10.tail()
expo=2/(len(Close15)+1)
Ema10=ma.ewmaCal(Close15,10,expo)
Ema10.tail()
## 绘制出中国银行股价以及三种平均价的曲线图，直观展示均线走势、波动情况和差异性
plt.rcParams['font.sans-serif']=['SimHel']
plt.plot(Close15[10:],label="Close",color='k')
plt.plot(Sma10[10:],label="Sma10",color='r',linestyle='dashed')
plt.plot(Wma10[10:],label="Wma10",color='b',linestyle=':')
plt.plot(Ema10[10:],label="Ema10",color='G',linestyle='-.')
plt.title("中国银行价格均线")
plt.ylim(3.5,5.5)
plt.legend()


### 30.7 均线时间跨度
Sma5=ma.smaCal(Close15,5)
Sma30=ma.smaCal(Close15,30)
plt.rcParams['font.sans-serif']=['SimHei']
plt.plot(Close15[30:],label="Close",color="k")
plt.plot(Sma5[30:],label="Sma5",color='b',linestyle='dashed')
plt.plot(Sma30[30:],label='Sma30',color='r',linestyle=':')
plt.title("中国银行股票价格的长短期均线")
plt.ylim(3.5,5.5)
plt.legend()


### 30.8 中国银行股票均线系统交易
### 30.8.1 简单移动平均线制定中国银行股票的买卖点
CBSma10=ma.smaCal(CBClose,10)
SmaSignal=pd.Series(0,index=CBClose.index)
for i in range(10,len(CBClose)):
    if all ([CBClose[i]>CBSma10[i],CBClose[i-1]<CBSma10[i-1]]):
        SmaSignal[i]=1
    elif all ([CBClose[i]<CBSma10[i],CBClose[i-1]>CBSma10[i-1]]):
        SmaSignal[i]=-1
SmaTrade=SmaSignal.shift(1).dropna()
SmaTrade.head(3)
SmaBuy=SmaTrade[SmaTrade==1]
SmaBuy.head(3)
SmaSell=SmaTrade[SmaTrade==-1]
SmaSell.head(3)
# 计算单期日收益率
CBRet=CBClose/CBClose.shift(1)-1
SmaRet=(CBRet*SmaTrade).dropna()
# 累计收益率表现
cumStock=np.cumprod(1+CBRet[SmaRet.index[0]:])-1
cumTrade=np.cumprod(1+SmaRet)-1
cumdata=pd.DataFrame({'cumTrade':cumTrade,'cumStock':cumStock})
cumdata.iloc[-6:,:]
# 绘制累计收益率图
plt.plot(cumStock,label='cumStock',color='k')
plt.plit(cumTrade,label='cumTrade',color='r',linestyle=':')
plt.title("股票本身与均线交易的累计收益率")
plt.legend()
# 求买卖点预测准确率
SmaRet[SmaRet==(-0)]=0
smaWinrate=len(SmaRet[SmaRet>0])/len(SmaRet[SmaRet!=0])
print(smaWinrate)

### 30.8.2 双均线交叉捕捉中国银行股票的买卖点
# 计算5日sma
# 计算30日sma
Ssma5=ma.smaCal(CBClose,5)
Lsma30=ma.smaCal(CBClose,30)
SLSignal=pd.Series(0,index=Lsma30.index)
for i in range(1,len(Lsma30)):
    if all ([Ssma5[i]>Lsma30[i],Ssma5[i-1]<Lsma30[i-1]]):
        SLSignal[i]=1
    elif all ([Ssma5[i]<Lsma30[i],Ssma5[i-1]>Lsma30[i-1]]):
        SLSignal[i]=-1
SLSignal[SLSignal==1]
SLSignal[SLSignal==-1]
SLTrade=SLSignal.shift(1)
Long=pd.Series(0,index=Lsma30.index)
Long[SLTrade==1]=1
CBRet=CBClose/CBClose.shift(1)-1
LongRet=(Long*CBRet).dropna()
winLrate=len(LongRet[LongRet>0])/len(LongRet[LongRet!=0])
print(winLrate)
# 从winLrate的值为0.5可以看出，双均线交叉捕捉买入点的预测准确率为50%
# 计算卖出点的预测获胜率
Short=pd.Series(0,index=Lsma30.index)
Short[SLTrade==-1]=-1
ShortRet=(Short*CBRet).dropna()
winStrate=len(ShortRet[ShortRet>0])/len(ShortRet[ShortRet!=0])
print(winStrate)
# 双均线交叉捕捉卖出点的预测准确率为40%
# 计算所有买卖点的预测获胜率
SLtradeRet=(SLTrade*CBRet).dropna()
winRate=len(SLtradeRet[SLtradeRet>0])/len(SLtradeRet[SLtradeRet!=0])
print(winRate)
cumLong=np.cumprod(1+LongRet)-1
cumShort=np.cumprod(1+ShortRet)-1
cumSLtrade=np.cumprod(1+SLtradeRet)-1
plt.rcParams['axes.unicode_minus']=False
plt.plot(cumSLtrade,label='cumSLtrade',color='k')
plt.plot(cumLong,label='cumStock',color='b',linestyle='dashed')
plt.plot(cumShort,label="cumTrade",color='r',linestyle=':')
plt.title("长短期均线交易累计收益率")
plt.legend(loc='best')


### 30.9 异同移动平均线MACD
# 快速线DIF=12日指数加权移动平均值-26日指数加权移动平均值
# 慢速线DEA是DIF的9日指数加权移动平均值
# 柱状图MACD由快速线DIF与慢速线DEA作差得到
### 30.9.1 MACD的求职过程
DIF=ma.ewmaCal(CBClose,12,2/(1+12))-ma.ewmaCal(CBClose,26,2/(1+26))
DIF.tail()
DEA=ma.ewmaCal(DIF,9,2/(1+9))
DEA.tail()
MACD=DIF-DEA
MACD.tail()
plt.rcParams['font.sans-serif']=['SimHei']
plt.subplot(211)
plt.plot(DIF['2015'],label="DIF",color='k')
plt.plot(DEA['2015'],label="DEA",color='b',linestyle='dashed')
plt.title("信号线DIF与DEA")
plt.legend()
plt.subplot(212)
plt.bar(left=MACD['2015'].index,height=MACD['2015'],label='MACD',color='r')
plt.legend()

# 30.9.2 异同均线MACD捕捉中国银行股票的买卖点
macddata=pd.DataFrame()
macddata['DIF']=DIF['2015']
macddata['DEA']=DEA['2015']
macddata['MACD']=MACD['2015']
import candle # 28章
candle.candleLinePlots(ChinaBank['2015'],candleTitle='中国银行2015年日K线图',splitFigures=True,Data=macddata,ylabel='MACD')
# 当DIF和DEA都在零线以上，表明市场可能是多头行情；当DIF和DEA都在零线以下，表明市场可能是空头行情
# DIF和DEA都在零线以上，一段时间内，DIF先上穿DEA，不久DIF下跌到DEA线下方，然后DIF又上穿DEA线，说明股价上升趋势较强
# DIF下穿DEA时，释放买入信号；DIF上穿DEA时，释放卖出信号
# 柱形图在零线附近释放出买卖信号；柱形图在零线上方，DIF>DEA，市场走势较强；柱形图在零线下方，DIF<DEA，市场走势较弱
macdSignal=pd.Series(0,index=DIF.index[1:])
for i in range(1,len(DIF)):
    if all([DIF[i]>DEA[i]>0.0,DIF[i-1]<DEA[i-1]]):
        macdSignal[i]=1
    elif all([DIF[i]<DEA[i]<0.0,DIF[i-1]>DEA[i-1]]):
        macdSignal[i]=-1
macdSignal.tail()
macdTrade=macdSignal.shift(1)
CBRet=CBClose/CBClose.shift(1)-1
macdRet=(CBRet*macdTrade).dropna()
macdRet[macdRet==-0]=0
macdWinRate=len(macdRet[macdRet>0])/len(macdRet[macdRet!=0])
print(macdWinRate)


### 30.10 多种均线指标综合运用模拟实测
# 合并交易信号
AllSignal=SmaSignal+SLSignal+macdSignal
for i in AllSignal.index:
    if AllSignal[i]>1:
        AllSignal[i]=1
    elif AllSignal[i]<-1:
        AllSignal[i]=-1
    else:
        AllSignal[i]=0
AllSignal[AllSignal==1]
AllSignal[AllSignal==-1]
tradSig=AllSignal.shift(1).dropna()
# 设定初始资产20000元，根据买卖点讯号，进行中国银行模拟交易
Close=CBClose[-n1:]
asset=pd.Series(0.0,index=Close.index)
cash=pd.Series(0.0,index=Close.index)
share=pd.Series(0,index=Close.index)
# 当价格连续两天上升并且交易信号没有显示卖出时，第一次开账户持有股票
entry=3
cash[:entry]=20000
while entry<len(CBClose):
    cash[entry]=cash[entry-1]
    if all([CBClose[entry-1]>=CBClose[entry-2],CBClose[entry-2]>=CBClose[entry-3],AllSignal[entry-1]!=-1]):
        share[entry]=1000
        cash[entry]=cash[entry]-1000*CBClose[entry]
        break
    entry+=1
i=entry+1
while i<len(tradSig):
    cash[i]=cash[i-1]
    share[i]=share[i-1]
    if tradSig[i]==1:
        share[i]=share[i]+3000
        cash[i]=cash[i]-3000*CBClose[i]
    if all([tradSig[i]==-1,share[i]>=1000]):
        share[i]=share[i]-1000
        cash[i]=cash[i]+1000*CBClose[i]
    i+=1
asset=cash+share*CBClose
# 最后，对我们的交易进行一些评价，绘制交易账户的曲线图并计算总资产收益率
# 绘制交易账户曲线图
plt.subplot(411)
plt.title("2014-2015年上：中国银行均线交易账户")
plt.plot(CBClose,color='b')
plt.ylabel("Price")
plt.subplot(412)
plt.plot(share,color='b')
plt.ylabel("Share")
plt.ylim(0,max(share)+1000)
plt.subplot(413)
plt.plot(asset,label="asset",color='r')
plt.ylabel("Asset")
plt.ylim(min(asset)-5000,max(asset)+5000)
plt.subplot(414)
plt.plot(cash,label="cash",color='g')
plt.ylabel("Cash")
plt.ylim(0,max(cash)+5000)
# 计算资产收益率（不考虑交易成本）
TradeReturn=(asset[-1]-20000)/20000
TradeReturn
