def function(list1):
    counter = 0
    for i in range(list1):
        if i > 0:
            counter = counter + 1
        else:
            continue
    return counter
list1 = [1, 2, 3, 0, -1, -2, -3]
result = list(map(function, list1))
print(result)
