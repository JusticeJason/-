### 24 时间序列预测
### 24.1 移动平均预测
### 24.1.1 简单易懂平均
### 24.1.2 加权移动平均
### 24.1.3 指数加权移动平均

### 24.2 ARMA模型预测
### 24.2.1 自回归模型（AR模型）
### 24.2.2移动平均模型（MA模型）

### 24.3 自回归移动平均模型

### 24.4 ARMA模型的建模过程
# 1.序列识别 ：非平稳序列→平稳序列；白噪声序列→建模结束
# 2.模型识别与估计
# 3.模型诊断：对模型残差进行检验，确保其为服从正态分布的白噪声序列

### 24.5 CPI数据的ARMA短期预测
### 24.5.1 序列识别
import pandas as pd
CPI=pd.read_csv('003/CPI.csv',index_col='time')
CPI.index=pd.to_datetime(CPI.index)
print(CPI.head(n=3))
print(CPI.tail(n=3))
print(CPI.shape) # 读取矩阵的长度
# 剔除最后3期数据，构造用于建模的数据子集
CPItrain=CPI[3:]
# 绘制时序图，直观了解数据情况
CPI.sort().plot(title='CPI 2005-2014') # sort排序
# 加载ADF函数
from arch.unitroot import ADF
# 进行ADF单位根检验，并查看结果
# 最大滞后阶数设为10
# 防止使用的滞后阶数过多导致p-value降低
CPItrain=CPItrain.dropna().CPI
print(ADF(CPItrain,max_lags=10).summary().as_text)
# 统计量足够小，则可认为序列是平稳的
# LB检验判断CPI序列是否为白噪声
from statsmodels.tsa import stattools
LjungBox=stattools.q_stat(stattools.acf(CPItrain)[1:12],len(CPItrain))
print(LjungBox[1][-1])
# p值足够小，则可认为CPI序列不是白噪声序列
### 24.5.2 模型识别与估计
# 识别模型的参数p和q
from statsmodels.graphics.tsaplots import *
from matplotlib import pyplot as plt
# 将画面一分为二
# 在第一个画面中画出序列的自相关系数图
# 在第二个画面画出序列的偏自相关系数图
axe1=plt.subplot(121)
axe2=plt.subplot(122)
plot1=plot_acf(CPItrain,lags=30,ax=axe1)
plot2=plot_pacf(CPItrain,lags=30,ax=axe2)
# 我们发现序列的自相关系数和偏自相关系数都呈现出拖尾的性质，因此可以初步判断p>0,q>0
# p和q的具体取值还无法判断，故考虑建立起低价p、q的各种组合情况下的ARMA模型，选出AIC值最小的模型
from statsmodels.tsa import arima_model
model1=arima_model.ARIMA(CPItrain,order=(1,0,1)).fit() # 308.678
print(model1.summary())
# 同理，我们建立起其他阶数的模型
model2=arima_model.ARIMA(CPItrain,order=(1,0,2)).fit() # 307.779
print(model2.summary)
model3=arima_model.ARIMA(CPItrain,order=(2,0,1)).fit() # 309.013
model4=arima_model.ARIMA(CPItrain,order=(2,0,2)).fit() # 309.271
model5=arima_model.ARIMA(CPItrain,order=(3,0,1)).fit() # 310.972
model6=arima_model.ARIMA(CPItrain,order=(3,0,2)).fit() # 299.759
# 将模型的AIC值汇总，可以得知，ARAMA(3,2)模型的AIC值最小，是备选模型中最好的模型
### 24.5.3 模型诊断
# 如果残差序列是白噪声序列，则说明我们的模型已充分提取了序列的信息
# 首先我们运用confint()函数计算模型中系数的置信区间
print(model6.conf_int())
# 对于残差序列的纯随机性的检验
# 绘制时间序列模拟的诊断图
import math
stdresid=model6.resid/math.sqrt(model6.sigma2)
plt.plot(stdresid)
plot_acf(stdresid,lags=20)
LjungBox=stattools.q_stat(stattools.acf(stdresid)[1:13],len(stdresid))
print(LjungBox[1][-1])
# 增加Ljung-Box检验的滞后阶数
LjungBox=stattools.q_stat(stattools.acf(stdresid)[1:20],len(stdresid))
print(LjungBox[1][-1])
# 绘制最大滞后阶数为40的自相关系数图
plot_acf(stdresid,lags=40)
### 24.5.4 运用模型进行预测
model6.forecast(3)[0] # 预测值
print(CPI.head(3)) # 原数据

### 24.6 股票收益率的平稳时间序列建模
import pandas as pd
Datang=pd.read_csv('024/Datang.csv',index_col='time')
Datang.index=pd.to_datetime(Datang.index)
returns=Datang.datang['2014-01-01':'2016-01-01']
print(returns.head(n=3))
print(ADF(returns).summary)
# 检验序列是否为白噪声
result=stattools.q_stat(stattools.acf(returns)[1:12],len(returns))[1]
print(result)
# 平稳且不是白噪声，建立ARMA模型
## arima建模
# max_ma参数用于指定最大ma滞后阶数
result2=stattools.arma_order_select_ic(returns,max_ma=4)
# print(result2)
# 根据上述结果，选择ARMA(1,0)模型
# 查看模型结果
model=arima_model.ARI(returns,order=(1,0,0)).fit()
print(model.summary())
model.conf_int()
# 残差诊断
stdresid=model.resid/math.sqrt(model.sigma2)
plt.plot(stdresid)
plot_acf(stdresid,lags=12)
LjungBox=stattools.q_stat(stattools.acf(stdresid)[1:12],len(stdresid))
print(LjungBox[1][-1])
# 残差项之间没有显著的自相关性，LB检验也有足够高的p值，即残差序列白噪声的原假设不能被拒绝
# 我们的模型满足要求



# 任意数据自尝试
import pandas as pd
from statsmodels.tsa import stattools
Datang=pd.read_csv('600015.csv',index_col='Trddt')
Datang.index=pd.to_datetime(Datang.index)
returns=Datang
# print(returns.head(n=3))
# 检验序列是平稳的
from arch.unitroot import ADF
# print(ADF(returns).summary)
# 检验序列是否为白噪声
result=stattools.q_stat(stattools.acf(returns)[1:12],len(returns))[1]
# print(result)
# 平稳且不是白噪声，建立ARMA模型（实际上这组随机数据并不是平稳的）
## arima建模
# max_ma参数用于指定最大ma滞后阶数
result2=stattools.arma_order_select_ic(returns,max_ma=4)
print("*** *** *** ***")
# print(result2)
# 根据上述结果，选择ARMA(1,0)模型
# 查看模型结果
from statsmodels.tsa import arima_model
model=arima_model.ARIMA(returns,order=(1,0,0)).fit()
print(model.summary())