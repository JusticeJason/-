### 28 动量交易策略
### 28.3 价格动量的计算公式
### 28.3.1 作差法求动量值
## 先获取万科股票数据，提取收盘价Close数据，定义滞后5期收盘价的变量lag5Close，进行作差
import pandas as pd
import matplotlib.pyplot as plt
from pandas.io.pytables import performance_doc
# 获取万科股票日度数据
Vanke=pd.read_csv('Vanke.csv')
Vanke.index=Vanke.Date # 原代码：Vanke.index=Vanke.iloc[:,1]
Vanke.index=pd.to_datetime(Vanke.index,format="%Y-%m-%d")
# 原代码：Vanke=Vanke.iloc[:,2:]
print(Vanke.head(2))
# 提取收盘价
Close=Vanke.Close
Close.describe()
# 求滞后5期的收盘价变量
lag5Close=Close.shift(5)
# 求5日动量
momentum5=Close-lag5Close
momentum5.tail()
## 绘制万科收盘价曲线图和5日动量曲线图
plt.rcParams['font.sans-serif']=['SimHei']
plt.subplot(211)
plt.plot(Close,'b*')
plt.xlabel('date')
plt.ylabel('Close')
plt.title('万科股价5日动量图')

# ### 28.3.2 做除法求动量值
Momen5=Close/lag5Close-1
Momen5=Momen5.dropna()
print(Momen5[:5])


### 28.4 编写动量函数momentum()
def momentum(price,period):
    lagPrice=price.shift(period)
    momen=price-lagPrice
    momen=momen.dropna()
    return(momen)
print(momentum(Close,5).tail(5))


# ### 28.5 万科股票2015年走势及35日动量线
# momen35=momentum(Close,35)
# import pandas as pd
# import matplotlib.pyplot as plt
# from matplotlib.dates import DateFormatter,WeekdayLocator,DayLocator,MONDAY,date2num
# from mpl_finance import candlestick_ochl
# plt.rcParams['font.sans-serif']=['SimHei']
# plt.rcParams['axes.unicode_minus']=False

# # 定义candleLinePlots()函数
# def candleLinePlots(candleData,candleTitle='a',**kwargs):
#     Date=[date2num(date) for date in candleData.index]
#     candleData.loc[:,'Date']=Date
#     listData=[]
#     for i in range(len(candleData)):
#         a=[candleData.Date[i],candleData.Open[i],candleData.High[i],candleData.Low[i],candleData.Close[i]]
#         listData.append(a)
#     # 如果不定长参数无取值，只画蜡烛图
#     ax=plt.subplot()
#     # 如果不定长参数有值，则分成两个子图
#     flag=0
#     if kwargs:
#         if kwargs['splitFigures']: # 此处有问题，但不知道问题在哪里
#             ax=plt.subplot(211)
#             ax2=plt.subplot(212)
#             flag=1
#         # 如果无参数splitFigures，则只画一个图形框
#         # 如果有参数splitFigures，则画出两个图形框
#             for key in kwargs:
#                 if key=='title':
#                     ax2.set_title(kwargs[key])
#                 if key=='ylabel':
#                     ax2.set_ylabel(kwargs[key])
#                 if key=='grid':
#                     ax2.grid(kwargs[key])
#                 if key=='Data':
#                     plt.sca(ax)
#                     if flag:
#                         plt.sca(ax2)
#                     # 一维数据
#                     if kwargs[key].ndim==1:
#                         plt.plot(kwargs[key],color='k',label=kwargs[key].name)
#                         plt.legend(loc='best')
#                     # 二维数据有两个columns
#                     elif all([kwargs[key].ndim==2,len(kwargs[key].columns)==2]):
#                         plt.plot(kwargs[key].iloc[:,0],color='k',label=kwargs[key].iloc[:,0].name)
#                         plt.plot(kwargs[key].iloc[:,1],linestyle='dashed',label=kwargs[key].iloc[:,1].name)
#                         plt.legend(loc='best')
#                     # 二维数据有3个columns
#                     elif all([kwargs[key].ndim==2,len(kwargs[key].columns)==3]):
#                         plt.plot(kwargs[key].iloc[:,0],color='k',label=kwargs[key].iloc[:,0].name)
#                         plt.plot(kwargs[key].iloc[:,1],linestyle='dashed',label=kwargs[key].iloc[:,1].name)
#                         plt.bar(left=kwargs[key].iloc[:,2].index,height=kwargs[key].iloc[:,2],color='r',label=kwargs[key].iloc[:,2].name)
#                         plt.legend(loc='best')
#     mondays=WeekdayLocator(MONDAY)
#     weekFormatter=DateFormatter('%y %b %d')
#     ax.xaxis.set_major_locator(mondays)
#     ax.xaxis.set_minor_locator(DayLocator())
#     ax.xaxis.set_major_formatter(weekFormatter)
#     plt.sca(ax)
#     candlestick_ochl(ax,listData,width=0.7,colorup='r',colordown='g')
#     ax.set_title(candleTitle)
#     plt.setp(ax.get_xticklabels(),rotation=20,horizontalalignment='center')
#     ax.autoscale_view()
#     return(plt.show())
# # 原代码：                 
# # import candle # 这个包已经废了
# # candle.candleLinePlots(Vanke['2015'],candleTitle='万科股票2015年日K线图',Data=momen35['2015'],title='35日动量',ylabel='35日动量')       
# candleLinePlots(Vanke['2015'],candleTitle='万科股票2015年日K线图',Data=momen35['2015'],title='35日动量',ylabel='35日动量')


### 28.6 动量交易策略的一般思路
## 运用动量指标交易万科股票
## 首先提取出万科股票的收盘价数据，计算35日动量值
Close=Vanke.Close
momen35=momentum(Close,35)
momen35.head()
## 结合35日动量值的取值情况来判断买卖点，35日动量释放的买卖点信号用signal表示
# 当35日动量值为负值是，signal取值为-1，表示卖出
# 当35日动量值为非负值时，signal取值为-1，表示买入
signal=[]
for i in momen35:
    if i>0:
        signal.append(1)
    else:
        signal.append(-1)
signal=pd.Series(signal,index=momen35.index)
signal.head()
## 根据买卖点制定买入和卖出交易，并计算收益率
tradeSig=signal.shift(1)
ret=Close/Close.shift(1)-1
Mom35Ret=(ret*tradeSig).dropna()
Mom35Ret[:5]
## 35日动量指标交易策略评价
# 计算指标交易获胜率
Mom35Ret[Mom35Ret==-0]=0
win=Mom35Ret[Mom35Ret>0]
winrate=len(win)/len(Mom35Ret[Mom35Ret!=0])
print(winrate)
# 绘制收益率时序图
# 显示中文；坐标轴显示负号
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
plt.subplot(211)
plt.plot(ret[-len(Mom35Ret):],'b')
plt.ylabel('return')
plt.ylim(-0.13,0.10)
plt.title('收益率时序图')
plt.subplot(212)
plt.plot(Mom35Ret,'r')
plt.ylabel('Mom35Ret')
plt.ylim(-0.13,0.10)
plt.title('动量交易收益率时序图')
# 直方图
loss=-Mom35Ret[Mom35Ret<0]
plt.subplot(211)
win.hist()
plt.title("盈利直方图")
plt.subplot(212)
loss.hist()
plt.title("损失直方图") # 图片显示有一点点问题（有可能是横坐标的问题）
# 计算两种收益率的平均值与分位数值
performance=pd.DataFrame({"win":win.describe(),"loss":loss.describe()})
print(performance)

