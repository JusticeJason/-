# 导入priceAnalysis2模块
import priceAnalysis2 as PrA
# Python在执行该语句时，程序首先在当前工作路径中搜寻priceAnalysis.py文件
# 若没有搜索到此文件，则会一一搜寻所有的系统路径来寻找此文件
# 如果还没有寻找到priceAnalysis.py文件，则会显示ImportError异常

price=[19,18,20,22,17,21]

print(PrA.OpenPrice(price))
print(PrA.ClosePrice(price))
print(PrA.HighPrice(price))
print(PrA.LowPrice(price))

# 通过os.getcwd()语句可以获取当前路径
# 通过sys.path语句获取当前系统路径中的所有路径
