### 22.2 Python中的时间序列数据
import pandas as pd
from pandas.core.base import ShallowMixin
Index=pd.read_table('TRD_Index.txt',sep='\t',index_col='Trddt')
SHindex=Index[Index.Indexcd==1]
# Indexcd 指数代码
# Trddt 交易日期
# Dayw 0为星期天
# Opnindex 开盘指数
# Hiindex 最高指数
# Loindex 最低指数
# Clsindex 收盘指数
# Retindex 指数收益率
# 查看数据SHindex的类型
type(SHindex) # pandas.core.frame.DataFrame
# 提取上证综指的收盘指数数据
Clsindex=SHindex.Clsindex
type(Clsindex) # pandas.core.series.Series
type(Clsindex.index) # pandas.core.index.Index
# 将收盘指数转换成时间序列格式
Clsindex.index=pd.to_datetime(Clsindex.index)
type(Clsindex) # pandas.core.series.Series
type(Clsindex.index) # pandas.core.index.DatetimeIndex
Clsindex.plot()

# 22.3 选取特定日期的时间序列数据
# 筛选出某一时间段内的数据：截取2014年10月8日到11月1日的数据
SHindex.index=pd.to_datetime(SHindex.index)
SHindexPart=SHindex['2014-10-08':'2014-10-31']
# 筛选某一特定年份的数据：截取2015年数据
SHindex2015=SHindex['2015']
# 选取某个时间点之前或者之后的数据：选取2015年初以后的数据、选取2015年以前的数据
SHindexAfter2015=SHindex['2015':]
SHindexBefore2015=SHindex[:'2014-12-31']
# 选取某一年中某几个月的数：选取2014年9月到年底的数据
SHindex9End=SHindex['2014-09':'2014']

# 22.4 时间序列数据描述性统计
# 绘制频数分布直方图
Clsindex.hist()


