### 25 GARCH模型
### 25.1 资产收益率的波动率与ARCH效应
# 波动率越高，期权价格越高

### 25.2 ARCH模型和GARCH模型
### 25.2.1 ARCH模型（自回归条件异方差模型）
### 25.2.2 GARCH模型（广义自回归条件异方差模型）
### 25.3 ARCH效应检验
# 1.检验收益率序列是否是平稳的时间序列，得到残差序列
# 2.对残差序列进行ARCH效应检验:
# (1)Ljung-Box检验，若残差序列有自相关性，初步判别序列有ARCH效应
# (2)Lagrange Multiplier检验，检验原假设为序列唔ARCH效应
# 3.设定波动率模型
# 4.对均值方程和波动率方程进行联合估计
# 5.检验所拟合的模型
import pandas as pd
# 上证综指收益率指数数据
SHret=pd.read_table('025/TRD_IndexSum.txt',index_col='Trddt',sep='\t')
SHret.index=pd.to_datetime(SHret.index)
SHret=SHret.sort()
# 绘制收益率平方序列图
import matplotlib.pyplot as plt
import numpy as np
plt.subplot(221)
plt.plot(SHret**2)
plt.xticks([])
plt.title('Squared Daily Return of SH Index')
plt.subplot(212)
plt.plot(np.abs(SHret))
plt.title('Absolute Daily Return of SH Index')
# 上证指数收益率序列存在很明显的波动聚集现象，初步判断其存在ARCH效应
# LB检验收益率平方的自相关性
from statsmodels.tsa import stattools
LjungBox=stattools.q_stat(stattools.acf(SHret**2)[1:13],len(returns)) # returns不知道哪里来的
print(LjungBox[1][-1])
# 检验的p值明显小于0.05，可以拒绝平方序列是白噪声的假设，即原序列存在ACRH效应

### GARCH模型构建
from arch import arch_model
# 设定模型
# arch_model默认建立GARCH(1,1)模型
am=arch_model(SHret)
# 估计参数
# update_freq=0表示不输出中间结果，只输出最终结果
model=am.fit(update_freq=0)
# 查看结果
print(model.summary)
# 结果中重要的参数：mu, omega, alpha, beta
