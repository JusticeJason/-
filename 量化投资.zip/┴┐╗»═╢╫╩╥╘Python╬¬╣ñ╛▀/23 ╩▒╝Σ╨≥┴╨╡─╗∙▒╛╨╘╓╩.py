### 23.时间序列的基本性质

### 23.1 自相关性
### 23.1.1 自协方差
### 23.1.2 自相关系数ACF：消除变量的度量单位
### 23.1.3 偏自相关系数PACF：衡量过去单期对现在的影响效果
### 23.1.4 acf()和pacf()函数
### 23.1.5 上证综指的收益率指数的自相关性判断
from statsmodels.tsa import stattools
import pandas as pd
data = pd.read_table('TRD_Index.txt',sep='\t',index_col='Trddt')
# 提取上证综指数据
SHindex=data[data.Indexcd==1]
SHindex.index=pd.to_datetime(SHindex.index)
SHRet=SHindex.Retindex
type(SHRet)
# 计算自相关系数
acfs=stattools.acf(SHRet)
print(acfs[:5])
# 计算偏自相关系数
pacfs=stattools.pacf(SHRet)
print(pacfs[:5])
# 绘制自相关系数图
from statsmodels.graphics.tsaplots import *
plot_acf(SHRet,use_vlines=True,lags=30)
# 绘制偏自相关图
plot_pacf(SHRet,use_vlines=True,lags=30)

### 23.2 平稳性
### 23.2.1 强平稳
### 23.2.2 弱平稳：三个条件
### 23.2.3 强平稳与弱平稳的区别

### 23.3 上证综指的平稳性检验
### 23.3.1 观察时间序列图
import matplotlib.pyplot as plt
SHClose=SHindex.Clsindx
SHClose.plot()
plt.title('2014-2015年上证综指收盘指数时序图')
SHRet.plot()
plt.title('2014-2015年上证综指收益率指数时序图')
### 23.3.2 观察序列的自相关图和偏自相关图
plot_acf(SHRet,use_vlines=True,lags=30)
plot_pacf(SHRet,use_vlines=True,lags=30)
plot_acf(SHClose,use_vlines=True,lags=30)
### 23.3.3 单位根检验
# 导入ADF函数
from arch.unitroot import ADF
# 单位根检验
adfSHRet=ADF(SHRet)
# ADF函数返回的是一个ADF类对象，不能直接输出，而是要借助summa()方法
print(adfSHRet.summary().as_text)
# 对上证综指收盘指数序列进行ADF检验
adfSHClose=ADF(SHClose)
print(adfSHClose.summary().as_text)

### 23.4 白噪声
### 23.4.1 白噪声
# 白噪声过程中各期变量之间的协方差为0，也就是说白噪声过程是没有相关性的
# 高斯白噪声过程：白噪声过程中各变量独立同分布，且都服从正态分布
# 生成纯随机序列
whiteNoise=np.random.standard_normal(size=500)
# 绘制该序列图
plt.plot(whiteNoise,c='b')
plt.title('White Noise')
# 第一行代码表示生成一组均值为0，方差为1的正态分布随机序列，该序列中一共有500个随机数
### 23.4.2 白噪声检验——Ljung-Box检验
# q_stat(x, nobs, type="ljungbox")函数实现LB检验过程
### 23.4.3 上证综指的白噪声检验
LjungBox1=stattools.q_stat(stattools.acf(SHRet)[1:13],len(SHRet))
print(LjungBox1)
print(LjungBox1[1][-1])
LjungBox2=stattools.q_stat(stattools.acf(SHClose)[1:13],len(SHRet))
print(LjungBox2[1][-1])



### 23.时间序列的基本性质 自尝试副本
from statsmodels.tsa import stattools
import pandas as pd
data = pd.read_csv('600015.csv',index_col='Trddt')
data.index=pd.to_datetime(data.index)
# print(type(data))
acfs=stattools.acf(data)
# print(acfs[:5])
# 计算偏自相关系数
pacfs=stattools.pacf(data)
# print(pacfs[:5])
# 绘制自相关系数图
from statsmodels.graphics.tsaplots import *
# plot_acf(data,use_vlines=True,lags=30)
# plot_pacf(data,use_vlines=True,lags=30)
import matplotlib.pyplot as plt
# data.plot()
# plt.title('模拟2014-2015年上证综指收盘指数时序图')
from arch.unitroot import ADF
adfSHRet=ADF(data)
print("*** *** ***")
# print(adfSHRet.summary().as_text)
# <bound method Summary.as_text of <class 'statsmodels.iolib.summary.Summary'>
# """
#    Augmented Dickey-Fuller Results   
# =====================================
# Test Statistic                 -1.094
# P-value                         0.718
# Lags                                0
# -------------------------------------

# Trend: Constant
# Critical Values: -3.46 (1%), -2.87 (5%), -2.57 (10%)
# Null Hypothesis: The process contains a unit root.
# Alternative Hypothesis: The process is weakly stationary.
# """>
# Test Statistic是-1.094，大于Critical Values给出的1%、5%、10%显著性水平下的临界值
# 因此无法拒绝原假设，也就是说上证综指收盘指数序列是非平稳的
# 生成纯随机序列
whiteNoise=np.random.standard_normal(size=500)
# 绘制该序列图
# plt.plot(whiteNoise,c='b')
# plt.title('White Noise')
LjungBox1=stattools.q_stat(stattools.acf(data)[1:13],len(data))
print(LjungBox1)
# 该函数会返回两个array对象，我们一般只需要关注p值
print(LjungBox1[1][-1])
# 当LB检验统计量对应的p值大于所设定的显著性水平时，接受原假设，认为所检验序列为白噪声序列
# 例子中，Q统计量对应的p值很小，小于显著性水平5%，故该序列是存在自相关性的

