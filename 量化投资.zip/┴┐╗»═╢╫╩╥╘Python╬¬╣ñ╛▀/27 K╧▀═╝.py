### 27 K线图
### 27.1 K线图简介
### 27.2 Python绘制上证综指K线图
import pandas as pd
ssec2015=pd.read_csv('ssec2015.csv')
ssec2015=ssec2015.iloc[:,1:] # 删除第1列的冗杂数据
print(ssec2015.iloc[-3:,:]) # 查看最后三行数据
from matplotlib.dates import DateFormatter,WeekdayLocator,DayLocator,MONDAY,date2num
from datetime import datetime
# date2num将日期数据转换成浮点型数据，strptime将日期字符串按照年月日切分
ssec2015.Date=[date2num(datetime.strptime(date,"%Y-%m-%d")) for date in ssec2015.Date] # 这步貌似有问题
# read_csv读取的数据为DateFrame类型，candlestick_ohlc函数所传入的数据对象类型为序列类型
ssec15list=list()
for i in range(len(ssec2015)):
    ssec15list.append(ssec2015.iloc[i,:])
# 设定图像参数并绘制蜡烛图
# from matplotlib.finance import candlestick_ohlc
# 从matplotlib2.2.0版本开始,matplotlib.finance已经从matplotlib中剥离了,需要单独安装mpl_finance
# mpl_finance不建议使用，建议使用mplfinance，但是里面又没有candlestick_ohlc这个包...
from mpl_finance import candlestick_ohlc
import matplotlib.pyplot as plt
ax=plt.subplot()
mondays=WeekdayLocator(MONDAY)
WeekFormatter=DateFormatter('%y %b %d')
ax.xaxis.set_major_locator(mondays)
ax.xaxis.set_minor_locator(DayLocator())
ax.xaxis.set_major_formatter(WeekFormatter)
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
ax.set_title("上证综指2015年3月份K线图")
candlestick_ohlc(ax,ssec15list,width=0.7,colorup='r',colordown='g') # 这步好像有问题
plt.setp(plt.gca().get_xticklabels(),rotatiom=50,horizontalalignment='center')
plt.show()


### 27.3 Python捕捉K线图的形态
### 27.3.1 Python捕捉"早晨之星"
ssec2012=pd.read_csv('ssec2012.csv')
ssec2012.index=ssec2012.iloc[:,1]
ssec2012.index=pd.to_datetime(ssec2012.index,format='%Y-%m-%d')
ssec2012=ssec2012.iloc[:,2:]
ssec2012.head(2)
ssec2012.iloc[-2:,:]
# 提取开盘价数据
Close=ssec2012.Close
# 提取收盘价数据
Open=ssec2012.Open
## 捕捉绿色实体、红色实体和十字星的实体部分
# 计算每一个交易日期的收盘价与开盘价的差值ClOp
ClOp=Close-Open
print(ClOp.head())
# 简要总结收盘价与开盘价差值的分布情况
ClOp.describe()
# 捕捉绿色实体、十字星和红色实体
Shape=[0,0,0]
lag1ClOp=ClOp.shift(1)
lag2ClOp=ClOp.shift(2)
for i in range(3,len(ClOp)):
    if all([lag2ClOp[i]<-11,abs(lag1ClOp[i])<2,ClOp[i]>6,abs(ClOp[i])>abs(lag2ClOp[i]*0.5)]):
        Shape.append(1)
    else:
        Shape.append(0)
# 查看Shape中元素第一次取值为1的index
Shape.index(1)
# 定义十字星实体的位置
lagOpen=Open.shift(1)
lagClose=Close.shift(1)
lag2Close=Close.shift(2)
# 捕捉符合十字星位置的蜡烛图
Doji=[0,0,0]
for i in range(3,len(Open),1):
    if all ([lagOpen[i]<Open[i],lagOpen[i]<lag2Close[i],lagClose[i]<Open[i],(lagClose[i]<lag2Close[i])]):
        Doji.append(1)
    else:
        Doji.append(0)
Doji.count(1)
## 刻画下跌趋势
# 定义下跌趋势
# 先计算收益率
ret=Close/Close.shift(1)-1
lag1ret=ret.shift(1)
lag2ret=ret.shift(1)
# 寻找向下趋势
Trend=[0,0,0]
for i in range(3,len(ret)):
    if all ([lag1ret[i]<0,lag2ret[i]<0]):
        Trend.append(1)
    else:
        Trend.append(0)
## 自动寻找"早晨之星"形态
StarSig=[]
for i in range(len(Trend)):
    if all ([Shape[i]==1,Doji[i]==1,Trend[i]==1]):
        StarSig.append(1)
    else:
        StarSig.append(0)
# 捕捉上证综指2012年出现"早晨之星"形态的日期
for i in range(len(StarSig)):
    if StarSig[i]==1:
        print(ssec2012.index[i])
# 只出现1次早晨之星形态，日期为2012年9月6日
## 绘制2012年9月6日K线图
ssec201209=ssec2012['2012-08-21':'2012-09-30']
# 绘制K线图
import candle
candle.candelPlot(ssec201209,title='上证综指2012年9月份的日K线图')

### 27.3.2 Python语言捕捉"乌云盖顶"形态
import pandas as pd
ssec2011=pd.read_csv('ssec2011.csv')
ssec2011.index=ssec2011.iloc[:,1]
ssec2011.index=pd.to_datetime(ssec2011.index,format='%Y-%m-%d')
ssec2011=ssec2011.iloc[:,2:]
# 提取价格数据
Close11=ssec2011.Close
Open11=ssec2011.Open
# 刻画捕捉符合"乌云盖顶"形态的连续两个蜡烛实体
lagClose11=Close11.shift(1)
lagOpen11=Open11.shift(1)
Cloud=pd.Series(0,index=Close11.index)
for i in range(1,len(Close11)):
    if all([Close11[i]<Open11[i],lagClose11[i]>lagOpen11[i],Open11[i]>lagOpen11[i],Close11[i]<0.5*(lagClose11[i]+lagOpen11[i]),Close11[i]>lagOpen11[i]]):
        Cloud[i]=1
# 定义前期上升趋势
Trend=pd.Series(0,index=Close11.index)
for i in range(2,len(Close11)):
    if Close11[i-1]>Close[i-2]>Close11[i-3]:
        Trend[i]=1
# 寻找"乌云盖顶"形态
darkCloud=Cloud+Trend
darkCloud[darkCloud==2]
# "乌云盖顶"形态出现两次，交易日分别为2011年5月19日和8月16日
# 绘制上证综指2011年5月19日附近的K线图
ssec201105=ssec2011['2011-05-01':'2011-05-30']
import candle
candle.candlePlot(ssec201105,title='上证综指2011年5月份的日K线图')

