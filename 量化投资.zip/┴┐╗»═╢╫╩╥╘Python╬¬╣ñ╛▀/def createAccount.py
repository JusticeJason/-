def createAccount():
    userName = []
    userName = input('Please enter your user name')
    if (userName[0] >= 'a' and userName[0] <= 'z') or (userName[0] >= 'A' and userName[0] <= 'Z'):
        print("The user name is entered correctly")
    else:
        print("User name input error")
    password = []
    password = input('Please enter your password')
    if ((password[0] >= 'a' and password[0] <= 'z') or (password[0] >= 'A' and password[0] <= 'Z')) and (("_" in password) or ("*" in password) or ("#" in password)) and len(password) > 6:
        print("The password is entered correctly")
    else:
        print("Password input error")

createAccount()