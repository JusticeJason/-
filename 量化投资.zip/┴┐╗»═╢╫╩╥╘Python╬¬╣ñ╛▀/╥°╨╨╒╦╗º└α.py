# 编写一个银行账户类
class Account(object):

    # 该类具有用户名和余额这两个属性
    def __init__(self, id, balance):
        self.id = id
        # 将余额属性设为私有属性
        self.__balance = balance

    # 该类具有存款、取款的方法
    def deposit(self, money): 
        self.__balance += money
    def withdraw(self, money):
        self.__balance -= money 

    # 获取余额的方法
    def getBalance(self):
        return(self.__balance)

    # 修改余额的方法
    def setBalance(self, newBalance):
        if type(newBalance) != int:
            return("Attention! The type of id must be integer!")
        self.__balance = newBalance
# 创建一个该类的对象，用户名为Sam，余额为1000
account1 = Account('Sam', 1000)

# 存入500元，之后再取出1200元
account1.deposit(500)
account1.withdraw(1200)

# 查询余额
print(account1.getBalance())

# 修改余额
account1.setBalance(1000)
print(account1.getBalance())

