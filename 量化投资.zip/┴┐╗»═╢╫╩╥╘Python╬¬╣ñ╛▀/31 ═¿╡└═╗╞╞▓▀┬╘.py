### 31 通道突破策略
### 31.2 唐奇安通道
# 寻找一定时间内出现的最高价和最低价，分别作为通道的上下轨道
# 当价格突破通道的上轨道时，说明股价运动较为强势，则释放出买入信号
### 31.2.1 唐奇安通道刻画
# 读取中国联通的股票数据
from audioop import mul
import re
from turtle import up
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
ChinaUnicom=pd.read_csv('ChinaUniom.csv')
ChinaUnicom.index=ChinaUnicom.iloc[:,1]
ChinaUnicom.index=pd.to_datetime(ChinaUnicom.index,format='%Y-%m-%d')
ChinaUnicom=ChinaUnicom.iloc[:,2:]
# 提取收盘价、最高价和最低价数据
Close=ChinaUnicom.Close
High=ChinaUnicom.High
Low=ChinaUnicom.Low
# 设定上中下通道线初始值
upboundDC=pd.Series(0.0,index=Close.index)
downboundDC=pd.Series(0.0,index=Close.index)
midboundDC=pd.Series(0.0,index=Close.index)
# 求唐奇安上中下通道
for i in range(20,len(Close)):
    upboundDC[i]=max(High[(i-20):i])
    downboundDC[i]=min(Low[(i-20):i])
    midboundDC=0.5*(upboundDC[i]+downboundDC[i])
upboundDC=upboundDC[20:]
downboundDC=downboundDC[20:]
midboundDC=midboundDC[20:]
# 绘制2013年中国联通价格唐奇安通道上中下轨道线图
plt.rcParams['font.sans-serif']=['SimHei']
plt.plot(Close['2013'],label='Close',color='k')
plt.plot(upboundDC['2013'],label='upboundDC',color='b',linestyle='dashed')
plt.plot(midboundDC['2013'],label='midboundDC',color='r',linestyle='-.')
plt.plot(downboundDC['2013'],label='downboundDC',color='b',linestyle='dashed')
plt.title("2013年中国联通股价唐奇安通道")
plt.ylim(2.9,3.9)
plt.legend()
### 绘制中国联通2013年上半年的K线图及唐奇安通道
upDownDC=pd.DataFrame({'upboundDC':upboundDC,'downboundDC':downboundDC})
ChinaUnicom13=ChinaUnicom['2013-01-01':'2013-06-28']
import candle
candle.candleLinePlots(candleData=ChinaUnicom13,candleTitle='中国联通2013年上半年K线图及唐奇安通道',Data=upDownDC13)

### 31.2.2Python捕捉唐奇安通道突破
# 定义向上突破函数
def upbreak(tsLine,tsRefLine):
    n=min(len(tsLine),len(tsRefLine))
    tsLine=tsLine[-n:]
    tsRefLine=tsRefLine[-n:]
    signal=pd.Series(0,index=tsLine.index)
    for i in range(1,len(tsLine)):
        if all([tsLine[i]>tsRefLine[i],tsLine[i-1]<tsRefLine[i-1]]):
            signal[i]=1
    return(signal)
# 定义向下突破函数
def downbreak(tsLine,tsRefLine):
    n=min(len(tsLine),len(tsRefLine))
    tsLine=tsLine[-n:]
    tsRefLine=tsRefLine[-n:]
    signal=pd.Series(0,index=tsLine.index)
    for i in range(1,len(tsLine)):
        if all([tsLine[i]<tsRefLine[i],tsLine[i-1]>tsRefLine[i-1]]):
            signal[i]=1
    return(signal)
# 唐奇安通道突破策略
UpBreak=upbreak(Close[upboundDC.index[0]:],upboundDC)
DownBreak=downbreak(Close[downboundDC.index[0]:],downboundDC)
# 制定交易策略
# 上穿，signal为1
# 下穿，signal为-1
# 合并上下穿总信号
BreakSig=UpBreak-DownBreak
# 计算预测获胜率
tradeSig=BreakSig.shift(1)
ret=Close/Close.shift(1)-1
tradeRet=(ret*tradeSig).dropna()
tradeRet[tradeRet==-0]=0
winRate=len(tradeRet[tradeRet>0])/len(tradeRet[tradeRet!=0])
print(winRate)


### 31.3 布林带通道
# 定义布林带通道函数
def bbands(tsPrice,period=20,times=2):
    upBBand=pd.Series(0.0,index=tsPrice.index)
    midBBand=pd.Series(0.0,index=tsPrice.index)
    downBBand=pd.Series(0.0,index=tsPrice.index)
    sigma=pd.Series(0.0,index=tsPrice.index)
    for i in range(period-1,len(tsPrice)):
        midBBand[i]=np.nanmean(tsPrice[i-(period-1):(i+1)])
        sigma[i]=np.nanstd(tsPrice[i-(period-1):(i+1)])
        upBBand[i]=midBBand[i]+times*sigma[i]
        downBBand[i]=midBBand[i]-times*sigma[i]
    BBands=pd.DataFrame({'upBBand':upBBand[(period-1):],'midBBand':midBBand[(period-1):],'downBBand':downBBand[(period-1):],'sigma':sigma[(period-1):]})
    return(BBands)
# 计算20日布林带通道线
UnicomBBands=bbands(Close,20,2)
UnicomBBands.head()
# 绘制2013年布林带上下通道线
upDownBB=UnicomBBands[['downBBand','upBBand']]
upDownBB13=upDownBB['2013-01-01':'2013-06-28']
import candle
candle.candleLinePlots(candleData=ChinaUnicom13,candleTitle='中国联通2013年上半年布林带通道线',Data=upDownBB13)


### 31.4 布林带通道与市场风险
# 构造布林带风险函数
def CalBollRisk(tsPrice,multiplier):
    k=len(multiplier)
    overUp=[]
    belowDown=[]
    BollRisk=[]
    for i in range(k):
        BBands=bbands(tsPrice,20,multiplier[i])
        a=0
        b=0
        for j in range(len(BBands)):
            tsPrice=tsPrice[-(len(BBands)):]
            if tsPrice[j]>BBands.upBBand[j]:
                a+=1
            elif tsPrice[j]<BBands.downBBand[j]:
                b+=1
        overUp.append(a)
        belowDown.append(b)
        BollRisk.append(100*(a+b)/len(tsPrice))
    return(BollRisk)
# 计算中国联通股市不同年份的布林带风险
# 设定标准差的倍数向量
multiplier=[1,1.65,1.96,2,2.58]
# 计算不同年度的布林带风险
# 2010年
price2010=Close['2010-01-04':'2010-12-31']
CalBollRisk(price2010,multiplier)
# 2011年
price2011=Close['2011-01-04':'2011-12-31']
CalBollRisk(price2011,multiplier)
# 2012年
price2012=Close['2012-01-04':'2012-12-31']
CalBollRisk(price2012,multiplier)
# 2013年
price2013=Close['2013-01-04':'2013-12-31']
CalBollRisk(price2013,multiplier)


### 31.5 通道突破交易策略的制定
### 31.5.1 一般布林带上下通道突破策略
# 当股价向上突破布林带上通道时，股票可能产生了异常上涨，未来股价会跌落到布林带通道内部，此时宜做空；
# 布林带上下通道突破策略
BBands=bbands(Close,20,2)
upbreakBB1=upbreak(Close,BBands.upBBand)
downbreakBB1=downbreak(Close,BBands.downBBand)
# 信号出现2天后进行交易
upBBSig1=-upbreakBB1.shift(2)
downBBSig1=downbreakBB1.shift(2)
tradeSignal1=upBBSig1+downBBSig1
tradeSignal1[tradeSignal1==-0]=0
# 构造交易评价函数，设定函数参数为价格和交易信号
def perform(tsPrice,tsTradSig):
    ret=tsPrice/tsPrice.shift(1)-1
    tradRet=(ret*tsTradSig).dropna()
    ret=ret[-len(tradRet):]
    winRate=[len(ret[ret>0])/len(ret[ret!=0]),len(tradRet[tradRet>0])/len(tradRet[tradRet!=0])]
    meanWin=[np.mean(ret[ret>0]),np.mean(tradRet[tradRet>0])]
    meanLoss=[np.mean(ret[ret<0]),np.mean(tradRet[tradRet<0])]
    Performance=pd.DataFrame({'winRate':winRate,'meanWin':meanWin,'meanLoss':meanLoss})
    Performance.index=['Stock','Trade']
    return(Performance)
# 计算平均损失收益率、平均获胜收益率以及交易获胜率
Performance1=perform(Close,tradeSignal1)
print(Performance1)

### 31.5.2 特殊布林带通道突破策略
# 当价格线由布林带上通道线的上方下穿到布林带通道内部时，
# 说明股价从异常上升行期将要恢复到正常波动行期，股价短期有下跌趋势，此时做空
# 另一种布林带通道突破策略
# 价格向上穿下通道，做多
# 价格向下穿上通道，做空
upbreakBB2=upbreak(Close,BBands.downBBand)
downbreakBB2=downbreak(Close,BBands.upBBand)
# 交易执行
upBBSig2=upbreakBB2.shift(2)
downBBSig2=-downbreakBB2.shift(2)
tradSignal2=upBBSig2+downBBSig2
tradSignal2[tradSignal2==-0]=0
# 交易策略表现
Performance2=perform(Close,tradSignal2)
print(Performance2)
