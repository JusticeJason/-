from datetime import datetime

class Asset(object):

    share = 0
    buyTime = datetime.strptime('1900-01-01','%Y-%m-%d')
    sellTime = datetime.strptime('1900-01-01','%Y-%m-%d')

    def __init__(self, id, price):
        self.id = id
        self.price = price

    def buy(self, share, time):
        self.share += share
        self.buyTime = datetime.strptime(time,'%Y-%m-%d')

    def sell(self, share, time):
        self.share -= share
        self.sellTime = datetime.strptime(time,'%Y-%m-%d')

class NonShortableAsset(Asset):
    def sell(self, share, time):
        if self.share >= share:
            self.share -= share
            self.sellTime = datetime.strptime(time,'%Y-%m-%d')
        else:
            print('Not permitted! There are not enough share to sell!')
            print('Current share is ',self.share)

            return