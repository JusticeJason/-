# I.把属性和访问属性的方法放在同一个对象中
class Asset(object):
    """
    Asset class with specified attributes.
    """
    def __init__(self, id, price):
        self.id = id
        self.price = price

    def print_id(self):
        print('The ID of the asset is: %s' %(self.id))

asset3 = Asset('003',11.5)

# 通过“实例.属性名称”的方式调用
print(asset3)
print(asset3.id)
print(asset3.price)

# 通过“实例.方法”的方式调用
asset3.print_id()

# II.把属性和访问属性的方法放在同一个对象中
class Asset(object):
    """
    Asset class with specified attributes.
    """
    def __init__(self, id, price):
        self.__id = id # 加上两个下划线表示private属性
        self.__price = price # 通过“实例.属性名称”的方式调用会报错

    def print_id(self):
        print('The ID of the asset is: %s' %(self.id))

asset3 = Asset('003',11.5)

# 通过“实例.方法”的方式调用
asset3.print_id()

# III.把属性和访问属性的方法放在同一个对象中
class Asset(object):
    """
    Asset class with specified attributes.
    """
    def __init__(self, id, price):
        self.__id = id # 加上两个下划线表示private属性
        self.__price = price # 通过“实例.属性名称”的方式调用会报错
    
    # 在类的内部写出获取id的方法
    def getID(self):
        return(self.__id)

asset3 = Asset('003',11.5)

print(asset3.getID())

# IV.把属性和访问属性的方法放在同一个对象中
class Asset(object):
    """
    Asset class with specified attributes.
    """
    def __init__(self, id, price):
        self.__id = id # 加上两个下划线表示private属性
        self.__price = price # 通过“实例.属性名称”的方式调用会报错
    
    # 获取id的方法
    def getID(self):
        return(self.__id)
    
    # 修改id的方法
    def setID(self, idValue):
        if type(idValue) != str:
            return("Attention! The type of id must be string!")
        self.__id = idValue

asset3 = Asset('003',11.5)

print(asset3.getID())