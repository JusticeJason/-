### 26 配对交易策略
### 26.3 配对交易的步骤
### 26.3.1 股票对的选择
## 最小距离法
# 1.读取上证50指数调整后收盘价数据
from os import access
import pandas as pd
sh=pd.read_csv('026/sh50p.csv',index_col="Trddt")
sh.index=pd.to_datetime(sh.index)
# 定义配对形成期
formStart='2014-01-01'
formEnd='2015-01-01'
# 形成期数据
shform=sh[formStart:formEnd]
# 查看这50只股票形成期的前2期价格数据
print(shform.head(n=2))
# 提取中国银行股票的调整后收盘数据
PAf=shform['601988']
PBf=shform['600000']
# 将两只股票数据合在一起形成DataFrame
pairf=pd.concat([PAf,PBf],axis=1)
# 求形成期长度
print(len(pairf))
# 2.构造标准化价格之差平方累计SSD函数
import numpy as np
def SSD(priceX,priceY):
    if priceX is None or priceY is None:
        print('缺少价格序列')
    returnX=(priceX-priceX.shift(1))/priceX.shift(1)[1:]
    returnY=(priceY-priceY.shift(1))/priceY.shift(1)[1:]
    standardX=(returnX+1).cumprod()
    standardY=(returnY+1).cumprod()
    SSD=np.sum((standardX-standardY)**2)
    return(SSD)
# 求中国太保与保利地产价格的距离
dis=SSD(PAf,PBf)
print(dis)
# 将上证50指数的50只股票两两配对，一共可以产生1225个股票对，形成期为245天
# 按照上面的代码思路，可以算出1225个SSD，由小到大排序，可选取前5组作为配对交易策略的5个股票对

## 协整模型
from arch.unitroot import ADF
# 检验中国银行对数价格的一阶单整性
# 将中国银行股股价取对数
PAflog=np.log(PAf)
# 对中国太保对数价格进行单位根检验
adfA=ADF(PAflog)
print(adfA.summary().as_text()) # 大于，不能拒绝原假设，非平稳
# 将中国银行对数价格差分
retA=PAflog.diff()[1:]
adfretA=ADF(retA)
print(adfretA.summary().as_text()) # 小于，可以拒绝原假设，平稳
# 综上所述，中国银行的对数价格序列是一阶单整序列
# 对浦发银行价格数据取对数
PBflog=np.log(PBf)
# 浦发银行对数价格单位根检验
adfB=ADF(PBflog)
print(adfB.summary().as_text())
# 将中国银行对数价格进行差分
retB=PBflog.diff()[1:]
# 对中国石化对数价格的差分序列进行单位根检验
adfretB=ADF(retB)
print(adfretB.summary().as_text())
import matplotlib.pyplot as plt
PAflog.plot(label='601988ZGYH',style='--')
PBflog.plot(label='600050ZGLT',style='-')
plt.legend(loc='upper left')
plt.title('中国银行与浦发银行的对数价格时序图')
# 中国银行股票的对数价格与浦发银行股票的对数价格有一定的趋势，不是平稳的
# 绘制股票对数价格差分的时序图
retA.plot(label='601988ZGYH')
retB.plot(label='600050ZGLT')
plt.legend(loc='lower left')
plt.title('中国银行与浦发银行对数价格差分（收益率）')
# 中国银行与中国联通股票对数价格的差分序列是平稳的，整体上都在0附近上下波动
# 对浦发银行和中国银行的对数价格进行协整检验
# 回归分析
# 因变量是中国银行(A)股票的对数价格
# 自变量是浦发银行(B)股票的对数价格
import statsmodels.api as sm
model=sm.OLS(PBflog,sm.add_constant(PAflog)) # 普通最小二乘法
results=model.fit()
print(results.summary())
# 将二价格做线性回归，可以看出系数与截距项均统计显著
# 接着，对回归残差进行平稳性检验
# 提取回归截距项
alpha=results.params[0]
# 提取回归系数
beta=results.params[1]
# 求残差
spread=PBflog-beta*PAflog-alpha
print(spread.head())
# 绘制残差序列时序图
spread.plot()
plt.title('价差序列')
# 价差序列单位根检验
# 因为残差的均值为0，所以trend设为nc
adfSpread=ADF(spread,trend='nc')
# 在5%的显著性水平下，我们可以拒绝原假设，残差序列是平稳的
# 通过上述分析，我们得知浦发银行与中国银行股票的对数价格序列具有协整关系


### 26.3.2 配对交易策略的制定
## 最小距离法
# (1)计算标准化价格序列差SSD_pair，求出均值和标准差，设定开仓、平仓条件
# 中国银行标准化价格
standardA=(1+retA).cumprod()
# 浦发银行标准化价格
standardB=(1+retB).cumprod()
# 求中国银行与浦发银行标准化价格序列的价差
SSD_pair=standardB-standardA
print(SSD_pair.head())
meanSSD_pair=np.mean(SSD_pair)
sdSSD_pair=np.std(SSD_pair)
thresholdUp=meanSSD_pair+1.2*sdSSD_pair
thresholdDown=meanSSD_pair-1.2*sdSSD_pair
SSD_pair.plot()
plt.title("中国银行与浦发银行标准化价差序列（形成期）")
plt.axhline(y=meanSSD_pair,color='black')
plt.axhline(y=thresholdUp,color='green')
plt.axhline(y=thresholdDown,color='green')
# (2)设定交易期时间，选取交易期数据，寻找配对交易开仓和平仓位点
# 当价差线上穿mu+1.2sigma线时，反向开仓，当价差线回复到均线附近时，进行平仓
# 当价差线下穿mu-1.2sigma线时，正向开仓，当价差线回复到均线附近时，进行平仓
tradStart='2015-01-01'
tradEnd='2015-06-30'
PAt=sh.loc[tradStart:tradEnd,'601988']
PBt=sh.loc[tradStart:tradEnd,'600000']
def spreadCal(x,y):
    retx=(x-x.shift(1))/x.shift(1)[1:]
    rety=(y-y.shift(1))/y.shift(1)[1:]
    standardX=(1+retx).cumprod()
    standardY=(1+rety).cumprod()
    spread=standardX-standardY
    return(spread)
TradSpread=spreadCal(PBt,PAt)
TradSpread.describe()
TradSpread.plot()
plt.title("交易期价差序列")
plt.axhline(y=meanSSD_pair,color='black')
plt.axhline(y=thresholdUp,color='green')
plt.axhline(y=thresholdDown,color='green')

## 协整模型
spreadf=PBflog-beta*PAflog-alpha
mu=np.mean(spreadf)
sd=np.std(spreadf)
# 形成期
CoSpreadT=np.log(PBt)-beta*np.log(PAt)-alpha
print(CoSpreadT.describe())
CoSpreadT.plot()


### 26.4 构建PairTrading类
# 对于上文中进行配对的代码，我们可以将其编写为一个类
import re
import pandas as pd
import numpy as np
from arch.unitroot import ADF
import statsmodels.api as sm
class PairTrading:
    def SSD(self, priceX, priceY):
        if priceX is None or priceY is None:
            print('缺少价格序列')
        returnX=(priceX-priceX.shift(1))/priceX.shift(1)[1:]
        returnY=(priceY-priceY.shift(1))/priceY.shift(1)[1:]
        standardX=(returnX+1).cumprod()
        standardY=(returnY+1).cumprod()
        SSD=np.sum((standardY-standardX)**2)
        return(SSD)
    def SSDSpread(self,priceX,priceY):
        if priceX is None or priceY is None:
            print('缺少价格序列')
        retx=(priceX-priceX.shift(1))/priceX.shift(1)[1:]
        rety=(priceY-priceY.shift(1))/priceY.shift(1)[1:]
        standardX=(retx+1).cumprod()
        standardY=(rety+1).cumprod()
        spread=standardY-standardX
        return(spread)
    def cointegration(self,priceX,priceY):
        if priceX is None or priceY is None:
            print('缺少价格序列')
        priceX=np.log(priceX)
        priceY=np.log(priceY)
        results=sm.OLS(priceY,sm.add_constant(priceX)).fit()
        resid=results.resid
        adfSpread=ADF(resid)
        if adfSpread.pvalue>=0.05:
            print('''交易价格不具有协整关系.
            P-value of ADF test: %f
            Coefficients of regression:
            Intercept: %f
            Beta: %f
            ''' % (adfSpread.pvalue,results.params[0],results.params[1]))
            return(None)
        else:
            print('''交易价格具有协整关系.
            P-value of ADF test: %f
            Coefficients of regression:
            Intercept: %f
            Beta: %f
            ''' % (adfSpread.pvalue,results.params[0],results.params[1]))
            return(results.params[0],results.params[1])
    def CointegrationSpread(self,priceX,priceY,formPeriod,tradePeriod):
        if priceX is None or priceY is None:
            print('缺少价格序列')
        if not (re.fullmatch('\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}',formPeriod) or re.re.fullmatch('\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}',tradePeriod)):
            print('形成期或交易期格式错误')
        formX=priceX[formPeriod.split(':')[0]:formPeriod.split(':')[1]]
        formY=priceY[formPeriod.split(':')[0]:formPeriod.split(':')[1]]
        coefficients=self.cointegration(formX,formY)
        if coefficients is None:
            print('未形成协整关系，无法配对')
        else:
            spread=(np.log(priceY[tradePeriod.split(':')[0]:tradePeriod.split(':')[1]])-coefficients[0]-coefficients[1]*np.log(priceX[tradePeriod.split(':')[0]:tradePeriod.split(':')[1]]))
            return(spread)
    def calBound(self,priceX,priceY,method,formPeriod,tradePeriod,width=1.5):
        if not (re.fullmatch('\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}',formPeriod) or re.fullmatch('\d{4}-\d{2}-\d{2}:\d{4}-\d{2}-\d{2}',tradePeriod)):
            print('形成期格式错误')
        if method=='SSD':
            spread=self.SSDSpread(priceX[formPeriod.split(':')[0]:formPeriod.split(':')[1]],
                priceY[formPeriod.split(':')[0]:formPeriod.split(':')[1]])
            mu=np.mean(spread)
            sd=np.std(spread)
            UpperBound=mu+width*sd
            LowerBound=mu-width*sd
            return(UpperBound,LowerBound)
        elif method=='Cointergration':
            spread=self.CointegrationSpread(priceX,priceY,formPeriod,tradePeriod)
            mu=np.mean(spread)
            sd=np.std(spread)
            UpperBound=mu+width*sd
            LowerBound=mu-width*sd
            return(UpperBound,LowerBound)
        else:
            print('不存在该方法，请选择"SSD"或是"Cointergration"')

### 26.5 Python实测配对交易交易策略
# (1)获取数据，协整检验，找出配对比列和配对价差
# 配对交易实例
# 提取形成期数据
formStart='2014-01-01'
formEnd='2015-01-01'
PA=sh['601988']
PB=sh['600000']
PAf=PA[formStart:formEnd]
PBf=PB[formStart:formEnd]
# 形成期协整关系检验
# 中国银行一阶单整检验
log_PAf=np.log(PAf)
adfA=ADF(log_PAf)
print(adfA.summary().as_text())
adfAd=ADF(log_PAf.diff()[1:])
print(adfAd.summary().as_text())
# 浦发银行一阶单整检验
log_PBf=np.log(PBf)
adfB=ADF(log_PBf)
print(adfB.summary().as_text())
adfBd=ADF(log_PBf.diff()[1:])
print(adfBd.summary().as_text())
# 协整关系检验
model=sm.OLS(log_PBf,sm.add_constant(log_PAf)).fit()
model.summary()
alpha=model.params[0]
print(alpha)
beta=model.params[1]
print(beta)
# 残差单位根检验
spreadf=log_PBf-beta*log_PAf-alpha
adfSpread=ADF(spreadf)
print(adfSpread.summary().as_text)
# 价差在5%的置信水平下拒绝原假设，是平稳性序列，具有协整关系，线性回归回归系数统计显著
# (2)配对，计算价差平均数和标准差
mu=np.mean(spreadf)
sd=np.std(spreadf)
# (3)选取交易期价格数据，构造开仓平仓区间
# 设定交易期
tradStart='2015-01-01'
tradEnd='2015-06-30'
PAt=PA[tradStart:tradEnd]
PBt=PB[tradStart:tradEnd]
CoSpreadT=np.log(PBt)-beta*np.log(PAt)-alpha
CoSpreadT.describe()
# 绘制价差区间图
CoSpreadT.plot()
plt.title('交易期价差序列（协整配对）')
plt.axhline(y=mu,color='black')
plt.axhline(y=mu+0.2*sd,color='blue',ls='-',lw=2)
plt.axhline(y=mu-0.2*sd,color='blue',ls='-',lw=2)
plt.axhline(y=mu+1.5*sd,color='green',ls='--',lw=2.5)
plt.axhline(y=mu-1.5*sd,color='green',ls='--',lw=2.5)
plt.axhline(y=mu+2.5*sd,color='red',ls='-.',lw=3)
# (4)根据开仓平仓点指定交易策略，并模拟交易账户
level=(float('-inf'),mu-2.5*sd,mu-1.5*sd,mu-0.2*sd,mu+0.2*sd,mu+1.5*sd,mu+2.5*sd,float('inf'))
prcLevel=pd.cut(CoSpreadT,level,labels=False)-3
prcLevel.head()
# 构造交易信号函数
def TradeSig(prcLevel):
    n=len(prcLevel)
    signal=np.zeros(n)
    for i in range(1,n):
        if prcLevel[i-1]==1 and prcLevel[i]==2:
            signal[i]=-2
        elif prcLevel[i-1]==1 and prcLevel[i]==0:
            signal[i]=2
        elif prcLevel[i-1]==2 and prcLevel[i]==3:
            signal[i]=3
        elif prcLevel[i-1]==-1 and prcLevel[i]==-2:
            signal[i]=1
        elif prcLevel[i-1]==-1 and prcLevel[i]==0:
            signal[i]=2
        elif prcLevel[i-1]==-2 and prcLevel[i]==-3:
            signal[i]=-3
    return(signal)
signal=TradeSig(prcLevel)
position=[signal[0]]
ns=len(signal)
for i in range(1,ns):
    position.append(position[-1])
    if signal[i]==1:
        position[i]==1
    elif signal[i]==-2:
        position[i]==-1
    elif signal[i]==-1 and position[i-1]==1:
        position[i]==0
    elif signal[i]==2 and position[i-1]==-1:
        position[i]==0
    elif signal[i]==3:
        position[i]==0
    elif signal[i]==-3:
        position[i]==0
position=pd.Series(position,index=CoSpreadT.index)
position.tail()
def TradeSim(priceX,priceY,position):
    n=len(position)
    size=1000
    shareY=size*position
    shareX=[(-beta)*shareY[0]*priceY[0]/priceX[0]]
    cash=[2000]
    for i in range(1,n):
        shareX.append(shareX[i-1])
        cash.append(cash[i-1])
        if position[i-1]==0 and position[i]==1:
            shareX[i]=(-beta)*shareY[i]*priceY[i]/priceX[i]
            cash[i]=cash[i-1]-(shareY[i]*priceY[i]+shareX[i]*priceX[i])
        elif position[i-1]==0 and position[i]==-1:
            shareX[i]=(-beta)*shareY[i]*priceY[i]/priceX[i]
            cash[i]=cash[i-1]-(shareY[i]*priceY[i]+shareX[i]*priceX[i])
        elif position[i-1]==1 and position[i]==0:
            shareX[i]=0
            cash[i]=cash[i-1]-(shareY[i-1]*priceY[i]+shareX[i-1]*priceX[i])
        elif position[i-1]==-1 and position[i]==0:
            shareX[i]=0
            cash[i]=cash[i-1]-(shareY[i-1]*priceY[i]+shareX[i-1]*priceX[i])   
    cash=pd.Series(cash,index=position.index)
    shareY=pd.Series(shareY,index=position.index)
    shareX=pd.Series(shareX,index=position.index)
    asset=cash+shareY*priceY+shareX*priceX
    account=pd.DataFrame({'Position':position,'ShareY':shareY,'ShareX':shareX,'Cash':cash,'Asset':asset})
    return(account)
account=TradeSim(PLICCT,SinopecT,position) # ?
account.tail()
account.iloc[:,(0,1,2)].plot()
plt.title('配对交易账户')

