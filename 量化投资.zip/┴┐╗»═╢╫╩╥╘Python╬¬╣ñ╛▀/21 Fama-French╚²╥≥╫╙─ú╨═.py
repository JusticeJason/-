### 21 Fama-French三因子模型
### 21.1 Fama-French三因子模型的基本思想
# 市场风险溢酬因子，市值因子SMB(S,B)，账面市值比因子HML(L,M,H)

### 21.2 三因子模型之Python实现
from numpy import left_shift
import pandas as pd
import matplotlib.pyplot as plt
# 缺少书中原始数据
stock=pd.read_table('021/stock.txt',sep='\t',index_col='Trddt')
# 获取华夏银行的股票数据
# 股票代码是"600015.SH"，华夏银行的英文是"Hua Xia Bank"
HXBank=stock[stock.Stkcd==600015]
HXBank.index=pd.to_datetime(HXBank.index)
# 提取华夏银行的收益率数据
HXRet=HXBank.Dretwd
HXRet.name='HXRet'
HXRet.plot()
ThreeFactors=pd.read_table('021/ThreeFactors.txt',sep='\t',index_col='TradingDate')
# 将三因子数据转化成时间序列格式
ThreeFactors.index=pd.to_datetime(ThreeFactors.index)
# 截取2014年1月2日以后的数据
ThrFac=ThreeFactors['2014-01-02':]
# 获取三个因子变量
ThrFac=ThrFac.iloc[:,[2,4,6]]
# 合并收益率数据与三因子数据
HXThrFac=pd.merge(pd.DataFrame(HXRet),pd.DataFrame(ThrFac),left_index=True,right_index=True)
# 作出散点图，查看股票收益率和三个因子之间的相关性
plt.subplot(2,2,1)
plt.scatter(HXThrFac.HXRet,HXThrFac.RiskPremium2)
plt.subplot(2,2,2)
plt.scatter(HXThrFac.HXRet,HXThrFac.SMB2)
plt.subplot(2,2,3)
plt.scatter(HXThrFac.HXRet,HXThrFac.HML2)
# 建立多元回归模型
import statsmodels.api as sm
# OLS普通最小二乘法,add_constant将截距列添加到现有矩阵
regThrFac=sm.OLS(HXThrFac.HXRet,sm.add_constant(HXThrFac.iloc[:,1:4]))
result=regThrFac.fit()
print(result.summary())
# 用params属性提取模型的系数
print(result.params)