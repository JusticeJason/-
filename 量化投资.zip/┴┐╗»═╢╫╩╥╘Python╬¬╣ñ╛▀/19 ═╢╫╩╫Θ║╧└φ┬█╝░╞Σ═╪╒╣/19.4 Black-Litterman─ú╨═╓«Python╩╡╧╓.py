# Black-Litterman模型之Python实现
import numpy as np

# 定义函数
def blacklitterman(returns,tau,P,Q): # returns：历史收益率；tau：反映主观观点相对于先验信息的比重；P,Q：投资人看法
    # 计算出历史收益率之均值及协方差矩阵
    mu=returns.mean()
    sigma=returns.cov()
    # 用历史收益率均值作为先验预期收益之期望值
    pi1=mu
    # 结合投资者个人的观点（其中P，Q为已知的输入变量，Ω要自己计算）
    ts=tau*sigma
    Omega=np.dot(np.dot(P,ts)*np.eye(Q.shape[0])) # dot矩阵相乘；eye(m,n)返回m*n的单位矩阵；shape读取矩阵长度
    # 根据公式计算出后验分布之期望值er、协方差posteriorSigma
    middle=np.linalg.inv(np.dot(np.dot(P,ts),P.T)+Omega) # np.linalg.inv计算逆矩阵
    er=np.expand_dims(pi1,axis=0).T+np.dot(np.dot(np.dot(ts,P.T),middle),(Q-np.expand_dims(np.dot(P,pi1.T),axis=1)))
    # expand_dims:插入一个新轴，该轴将出现在expand数组shape的轴位置上
    posteriorSigma=sigma+ts-np.dot(ts.dot(P.T).dot(middle).dot(P),ts)
    return [er, posteriorSigma]

# 构建投资人的个人观点
