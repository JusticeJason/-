# 19.1 投资组合的收益率与风险
# 两个资产的情况
# 收益率Rp=总收益/初始投入资本=wARA+wBRB
# 两个资产组成的投资组合的方差P295
# 资产A和资产B收益率之间的相关系数ρA,B=σ(RA,RB)/σ(RA)σ(RB)
# 证券投资的风险=系统性风险+非系统性风险（又称可分散风险，可以通过分散化投资消除）
from matplotlib.transforms import Bbox
import numpy as np
import math
import matplotlib.pyplot as plt
def cal_mean(frac): # 计算期望收益率
    return(0.08*frac+0.15*(1-frac)) # 数据源自文中例子
mean=list(map(cal_mean,[x/50 for x in range(51)])) # 改变对A的投资比例，观测期望收益率变化
# 计算风险（收益率的标准差）
sd_mat=np.array([list(map(lambda x: math.sqrt((x**2)*0.12**2+((1-x)**2)*0.25**2+2*x*(1-x)*(-1.5+i*0.5)*0.12*0.25),[x/50 for x in range(51)])) for i in range(1,6)])
# 收益率随风险及投资比例的变化
# plt.plot(sd_mat[0,:],mean,label='-1')
# plt.plot(sd_mat[1,:],mean,label='-0.5')
# plt.plot(sd_mat[2,:],mean,label='0')
# plt.plot(sd_mat[3,:],mean,label='0.5')
# plt.plot(sd_mat[4,:],mean,label='1')
# plt.legend(loc='upper left')
# plt.show()
# N个资产的情况 略

# 19.2 Markowitz均值-方差模型
# 19.3 Markowitz模型之Python实现
import pandas as pd
# 读取数据（不同于例题，自行在网上下载了白云机场、华夏银行、浙能电力的股票以进行分析）
sh_return=pd.read_csv('019stock.csv',index_col='date')
print(sh_return.head())
# 查看各股的累计回报率
sh_return=sh_return.dropna()
cumreturn=(1+sh_return).cumprod()
# print(cumreturn)
sh_return.plot()
plt.title('Daily Return of 3 Stocks(2021-2022)')
plt.legend(loc='lower center',bbox_to_anchor=(0.5,-0.3),ncol=3,fancybox=True,shadow=True)
# bbox_to_anchor放置图例框，fancybox调节图示形状
plt.plot(cumreturn.index, cumreturn['byjc'])
plt.title('Cumulative Return of 3 Stocks(2021-2022)') # 存在一些问题
# 查看各股回报率相关性
corr=sh_return.corr()
# print(corr)
# 绘制热力图（自制）
import seaborn as sns
sns.heatmap(corr, cmap = "RdBu", square=True, annot = True)
# 投资者的资产配置问题——用二次规划问题表达；
# 该问题在数学上的一阶条件形式：构建MeanVariance类，根据输入的收益率序列，求解二次规划，计算最优资产比例，并绘制最小方差前缘曲线
# 定义MeanVariance类
from scipy import linalg
import ffn
class MeanVariance:
    # 定义构造器，传入收益率数据
    def __init__(self,returns):
        self.returns=returns
    @classmethod
    # 定义最小化方差的函数，即求解二次规划
    def minVar(self,goalRet):
        covs=np.array(self.returns.cov()) # 协方差
        means=np.array(self.returns.mean())
        # swapaxes交换维度，ones单位矩阵
        L1=np.append(np.append(covs.swapaxes(0,1),[means],0),[np.ones(len(means))],0).swapaxes(0,1)
        L2=list(np.ones(len(means)))
        # extend追加多个值
        L2.extend([0,0])
        L3=list(means)
        L3.extend([0,0])
        L4=np.array([L2,L3])
        L=np.append(L1,L4,0)
        results=linalg.solve(L,np.append(np.zeros(len(means)),[1,goalRet],0))
        return(np.array([list(self.returns.columns),results[:-2]]))
    # 定义绘制最小方差前缘函数
    def frontierCurve(self):
        goals=[x/500000 for x in range(-100,4000)]
        variances=list(map(lambda x: self.calVar(self.minVar(x)[1,:].astype(np.float)),goals))
        plt.plot(variances,goals)
    # 给定各资产的比例，计算收益率均值
    def meanRet(self,fracs):
        meanRisky=ffn.to_returns(self.returns).mean()
        assert len(meanRisky)==len(fracs),'Length of fractions must be equal to number of assets'
        return(np.sum(np.multiply(meanRisky,np.array(fracs))))
    # 给定各资产的比例，计算收益率方差
    def calVar(self,fracs):
        return(np.dot(np.dot(fracs,self.returns.cov()),fracs))
minVar=MeanVariance(sh_return)
minVar.frontierCurve() # 并没有出图
# 选取训练集和测试集
from sklearn.model_selection import train_test_split
result = train_test_split(sh_return.index,sh_return['byjc'],train_size=0.8, random_state=1)
# print("*** *** ***")
train_set = result[0]
test_set = result[1]
# 选取组合
varMinimizer=MeanVariance(train_set)
goal_return=0.003
portfolio_weight=varMinimizer.minVar(goal_return)
print(portfolio_weight)
# 计算测试集收益率
test_return=np.dot(test_set,np.array([portfolio_weight[1,:].astype(np.float)]).swapaxes(0,1))
test_return=pd.DataFrame(test_return,index=test_set.index)
test_cum_return=(1+test_return).cumprod()
# 与随机生成的组合进行比较
sim_weight=np.random.uniform(0,1,(100,5))
sim_weight=np.apply_along_axis(lambda x: x/sum(x),1,sim_weight)
sim_return=np.dot(test_set,sim_weight.swapaxes(0,1))
sim_return=pd.DataFrame(sim_return,index=test_cum_return.index)
sim_cum_return=(1+sim_return).cumprod()
plt.plot(sim_cum_return.index,sim_cum_return,color='green')
plt.plot(test_cum_return.index,test_cum_return)









