### 33 量价关系分析
### 33.2 量价关系分析
### 33.2.1 价涨量增
# 市场上出现诸多利好因素，说明股票价格未来处于回升阶段
from calendar import week
from re import sub
from signal import signal
from turtle import pos, position, title
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter,WeekdayLocator,DayLocator,MONDAY,date2num
from mpl_finance import candlestick_ohlc
import numpy as np
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
def candleVolume(seriesData,candletitle='a',bartitle=''):
    Date=[date2num(date) for date in seriesData.index]
    seriesData.index=list(range(len(Date)))
    seriesData['Date']=Date
    listData=zip(seriesData.Date,seriesData.Open,seriesData.High,seriesData.Low,seriesData.Close)
    ax1=plt.subplot(211)
    ax2=plt.subplot(212)
    for ax in ax1,ax2:
        mondays=WeekdayLocator(MONDAY)
        weekFormatter=DateFormatter('%m/%d/%Y')
        ax.xaxis.set_major_locator(mondays)
        ax.xaxis.set_minor_locator(DayLocator())
        ax.xaxis.set_major_formatter(weekFormatter)
        ax.grid(True)
    ax1.set_ylim(seriesData.Low.min()-2,seriesData.High.max()+2)
    ax1.set_ylabel("蜡烛图及收盘价线")
    candlestick_ohlc(ax1,listData,width=0.7,colorup='r',colordown='g')
    plt.setp(plt.gca().get_xticklabels(),rotation=20,horizontalalignment='center')
    ax1.autoscale_view()
    ax1.set_title(candletitle)
    ax1.plot(seriesData.Date,seriesData.Close,color='black',label='收盘价')
    ax1.legend(loc='best')
    ax2.set_ylabel('成交量')
    ax2.set_ylim(0,seriesData.Volume.max()*3)
    ax2.bar(np.array(Date)[np.array(seriesData.Close>=seriesData.Open)],
        height=seriesData.iloc[:,4][np.array(seriesData.Close>=seriesData.Open)],
        color='r',align='center')
    ax2.bar(np.array(Date)[np.array(seriesData.Close<seriesData.Open)],
        height=seriesData.iloc[:,4][np.array(seriesData.Close<seriesData.Open)],
        color='g',align='center')
    ax2.set_title(bartitle)
    return(plt.show())
from candle import candleVolume
CJSecurities1=CJSecurities['2015-04-01':'2015-04-30']

candleVolume(CJSecurities1,candletitle='长江证券2015年4月份蜡烛图',bartitle='长江证券2015年4月份日成交量')


### 33.2.2 价涨量平
# 市场可能翻转，预示着价格即将到达顶部
# 也有可能是市场处于调整期
# 还有可能是价格上涨过猛
### 33.2.3 价涨量缩
### 33.2.4 价平量增
# 多方力量可能进行了低拉布局
# 市场中出现了一些利好消息，多方力量逐渐增强，多方投资者预测到未来行情可能出现向上走势，在低位进场推动成交量上涨
# 股票市场在更换庄家
### 33.2.5 价平量缩
# 新一轮的上涨行情初期，调整洗盘
### 33.2.6 价跌量增
# 市场高价位下跌行情的初期，表面投资者不看好市场，卖方力量较大
# 在市场下跌末期市场中做多力量慢慢增强时，成交量会增加，但是多空力量的较量还不至于抬高股价
### 33.2.7 价跌量平
# 如果价跌量平跟随在价平量平后面，则表面市场已经开始下跌行情
### 33.2.8 价跌量缩
# 盘整阶段
# 单边下跌行情阶段，体现出市场即将出现止跌的情形，空方力量逐渐耗尽
# 单边下跌行情阶段，市场行情不好，买方力量极弱，市场中接盘量较小


### 33.3 不同价格段位的成交量
# 获取收盘价数据
close=CJSecurities.Close
close.describe()
# 调整收盘价数据
BreakClose=np.ceil(close/2)*2
BreakClose.name='BreakClose'
pd.DataFrame({'BreakClose':BreakClose,'Close':close}).head(2)
# 获取成交量数据
volume=CJSecurities.Volume
# 计算价格变化量
PrcChange=close.diff()
# 选取价格增大所对应交易日期的成交量
UpVol=volume.replace(volume[PrcChange>0],0)
UpVol[0]=0
# 获取价格下降所对应交易日期的成交量
DownVol=volume.replace(volume[PrcChange<=0],0)
DownVol[0]=0
# 构造函数，计算价格变化区间中的成交量之和
def VOblock(vol):
    return([np.sum(BreakClose==x) fpr x in range(6,22,2)])
# 计算价格变化区间中的价格上涨日期的成交量之和
cumUpVol=VOblock(UpVol)
# 计算价格变化区间中的价格下跌日期的成交量之和
cumDownVol=VOblock(DownVol)
# 按照行来合并VOP、VON数据
ALLVol=np.array([cumUpVol,cumDownVol]).transpose()
# 绘制价格变化量折线图并在原图的基础上画新的柱状图
import matplotlib.pyplot as plt
fig,ax=plt.subplots()
ax1=ax.twiny()
ax.plot(close)
ax.set_title('不同价格区间的累积成交量图')
ax.set_ylim(4,20)
ax.set_xlabel('时间')
plt.setp(ax.get_xticklabels(),rotation=20,horizontalignment='center')
ax1.barh(bottom=range(4,20,2),width=ALLVol[:,0],height=2,color='g',alpha=0.2)
ax1.barh(bottom=range(4,20,2),width=ALLVol[:,1],height=2,left=ALLVol[:,0],color='r',alpha=0.2)
plt.show()


### 33.4 成交量与均线思想结合制定交易策略
volume=CJSecurities.Volume
VolSMA5=pd.rolling_apply(volume,5,np.mean)
VolSMA10=pd.rolling_apply(volume,10,np.mean)
VolSMA=((VolSMA5+VolSMA10)/2).dropna()
VolSMA.head(3)
VolSignal=(volume[-len(VolSMA):]>VolSMA)*1
VolSignal[VolSignal==0]=-1
VolSignal.head()
close=CJSecurities.Close
PrcSMA5=pd.rolling_apply(close,5,np.mean)
PrcSMA20=pd.rolling_apply(close,20,np.mean)
def upbreak(Line,RefLine):
    signal=np.all([Line>RefLine,Line.shift(1)<RefLine.shift(1)],axis=0)
    return(pd.Series(signal[1:],index=Line.index[1:]))
def downbreak(Line,RefLine):
    signal=np.all([Line<RefLine,Line.shift(1)>RefLine.shift(1)],axis=0)
    return(pd.Series(signal[1:],index=Line.index[1:]))
UpSMA=upbreak(PrcSMA5[-len(PrcSMA20):],PrcSMA20)*1
DownSMA=downbreak(PrcSMA5[-len(PrcSMA20):],PrcSMA20)*1
SMAsignal=UpSMA-DownSMA
VolSignal=VolSignal[-len(SMAsignal):]
signal=VolSignal+SMAsignal
signal.describe()
trade=signal.replace([2,-2,1,-1,0],[1,-1,0,0,0])
trade=trade.shift(1)[1:]
trade.head()
ret=((close-close.shift(1))/close.shift(1))['2014-01-31':]
ret.name='stockRet'
tradeRet=trade*ret
tradeRet.name='tradeRet'
winRate=len(tradeRet[tradeRet>0])/len(tradeRet[tradeRet!=0])
print(winRate)

(1+ret).cumprod().plot(label='stockRet')
(1+tradeRet).cumprod().plot(label='tradeRet')
plt.legend()

def Hold(signal):
    hold=np.zeros(len(signal))
    for index in range(1,len(hold)):
        if hold[index-1]==0 and signal[index]==1:
            hold[index]=1
        elif hold[index-1]==1 and signal[index]==1:
            hold[index]=1
        if hold[index-1]==1 and signal[index]==0:
            hold[index]=1
    return(pd.Series(hold,index=signal.index))
hold=Hold(trade)

def TradeSim(price,hold):
    position=pd.Series(np.zeros(len(price)),index=price.index)
    position[hold.index]=hold.values
    cash=20000*np.ones(len(price))
    for t in range(1,len(price)):
        if position[t-1]==0 and position[t]==1:
            cash[t]=cash[t-1]-price[t]*1000
        if position[t-1]==2 and position[t]==0:
            cash[t]=cash[t-1]-price[t]*1000
        if position[t-1]==position[t]:
            cash[t]=cash[t-1]
    asset=cash+price*position*1000
    asset.name='asset'
    account=pd.DataFrame({'asset':'asset','cash':cash,'position':position})
    return(account)
TradeAccount=TradeSim(close,hold)
TradeAccount.tail()

TradeAccount.plot(subplots=True,title='成交量与均线策略交易账户')
