### 20.3 Python计算单资产CAPM实例
# 获取指数数据
import pandas as pd
indexcd=pd.read_csv('020/TRD_Index.csv',index_col='Trddt')
mktcd=indexcd[indexcd.Indexcd==902]
print(mktcd.head())
mktret=pd.Series(mktcd.Retindex.values,index=pd.to_datetime(mktcd.index))
mktret.name='mktret'
print(mktret.head())
mktret=mktret['2014-01-02':'2014']
print(mktret.tail()) # 取后五行
# 获取新安股份股票数据
xin_an=pd.read_csv('020/xin_an.csv',index_col='Date')
xin_an.index=pd.to_datetime(xin_an.index)
print(xin_an.head())
# 去除非交易日(Volume=0)的数据
xin_an=xin_an[xin_an.Volume!=0]
# 直接用收盘价计算收益率，也可以用调整后的收盘价
xin_anret=(xin_an.Close-xin_an.Close.shift(1)/xin_an.Close.shift(1))
xin_anret.name='returns'
xin_anret=xin_anret.dropna()
print(xin_anret.head())
print(xin_anret.tail())
# 将新安股份和市场指数收益率合并在一起，将没有交易的数据删除
Ret=pd.merge(pd.DataFrame(mktret),
    pd.DataFrame(xin_anret),
    left_index=True,right_index=True,how='inner')
# 计算无风险收益率
rf=1.036**(1/360)-1
print(rf)
# 计算股票超额收益率和市场风险溢酬
Eret=Ret-rf
print(Eret.head())
# 画出散点图
import matplotlib.pyplot as plt
plt.scatter(Eret.values[:,0],Eret.values[:,1])
plt.title('XinAnGuFen return and market return')
plt.show()
# 拟合CPAM模型
import statsmodels.api as sm
model=sm.OLS(Eret.returns[1:],sm.add_constant(Eret.mktret[1:]))
result=model.fit()
result.summary()
